#include "gioco.h"
#include "livello2.h"
#include "perso.h"
#include "ui_gioco.h"
#include "vinto.h"
#include <string>
#include <cstdlib>
#include <ctime>
#include <iostream>
int pianeta;
int riga_attiva = 1;
int combinazione[4] = {-1,-1,-1,-1};
int numeri[4] = {1,2,3,4};
int combinazione_vincente[4];
using namespace std;

void crea_comb(){
    int x = 0;
    srand(time(NULL));
    while(x<4){

        int n = rand()%4;

        if(numeri[n]!=-1){

            combinazione_vincente[x] = numeri[n];
            cout << combinazione_vincente[x] << endl;
            numeri[n] = -1;
            x++;

        }
    }
}

Gioco::Gioco(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Gioco)
{
    ui->setupUi(this);
    crea_comb();
}

Gioco::~Gioco()
{
    delete ui;
}

void Gioco::on_p_1_clicked()
{
    pianeta = 1;
}

bool riga_piena(){
    for(int x=0;x<4;x++){
        if(combinazione[x]==-1){
            return false;
        }
    }
    return true;
}

void Gioco::on_p_2_clicked()
{
    pianeta = 2;
}


void Gioco::on_p_3_clicked()
{
    pianeta =3;
}


void Gioco::on_p_4_clicked()
{
    pianeta =4;
}


void Gioco::on_r1c1_clicked()
{
    if(riga_attiva==1){
        ui->r1c1->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[0]=pianeta;
}


void Gioco::on_r1c2_clicked()
{
    if(riga_attiva==1){
        ui->r1c2->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[1]=pianeta;
}


void Gioco::on_r1c3_clicked()
{
    if(riga_attiva==1){
        ui->r1c3->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[2]=pianeta;
}


void Gioco::on_r1c4_clicked()
{
    if(riga_attiva==1){
        ui->r1c4->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[3]=pianeta;
}


void Gioco::on_r2c1_clicked()
{
    if(riga_attiva==2){
        ui->r2c1->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[0]=pianeta;
}


void Gioco::on_r2c2_clicked()
{
    if(riga_attiva==2){
        ui->r2c2->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[1]=pianeta;
}


void Gioco::on_r2c3_clicked()
{
    if(riga_attiva==2){
        ui->r2c3->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[2]=pianeta;
}


void Gioco::on_r2c4_clicked()
{
    if(riga_attiva==2){
        ui->r2c4->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[3]=pianeta;
}


void Gioco::on_r3c1_clicked()
{
    if(riga_attiva==3){
        ui->r3c1->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[0]=pianeta;
}


void Gioco::on_r3c2_clicked()
{
    if(riga_attiva==3){
        ui->r3c2->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[1]=pianeta;
}


void Gioco::on_r3c3_clicked()
{
    if(riga_attiva==3){
        ui->r3c3->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[2]=pianeta;
}


void Gioco::on_r3c4_clicked()
{
    if(riga_attiva==3){
        ui->r3c4->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[3]=pianeta;
}


void Gioco::on_r4c1_clicked()
{
    if(riga_attiva==4){
        ui->r4c1->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[0]=pianeta;
}


void Gioco::on_r4c2_clicked()
{
    if(riga_attiva==4){
        ui->r4c2->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[1]=pianeta;
}


void Gioco::on_r4c3_clicked()
{
    if(riga_attiva==4){
        ui->r4c3->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[2]=pianeta;
}


void Gioco::on_r4c4_clicked()
{
    if(riga_attiva==4){
        ui->r4c4->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[3]=pianeta;
}


void Gioco::on_r5c1_clicked()
{
    if(riga_attiva==5){
        ui->r5c1->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[0]=pianeta;
}


void Gioco::on_r5c2_clicked()
{
    if(riga_attiva==5){
        ui->r5c2->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[1]=pianeta;
}


void Gioco::on_r5c3_clicked()
{
    if(riga_attiva==5){
        ui->r5c3->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[2]=pianeta;
}


void Gioco::on_r5c4_clicked()
{
    if(riga_attiva==5){
        ui->r5c4->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta)+".png);"));
    }
    combinazione[3]=pianeta;
}



void Gioco::pallini(){
    int rossi = 0;
    for(int x=0;x<4;x++){

        if(combinazione[x]==combinazione_vincente[x]){
            rossi+=1;
            if(riga_attiva==1){
                if(rossi==1){
                    ui->pr1c1->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr1c1->setFlat(false);
                }
                if(rossi==2){
                    ui->pr1c2->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr1c2->setFlat(false);
                }
                if(rossi==3){
                    ui->pr1c3->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr1c3->setFlat(false);
                }
                if(rossi==4){
                    ui->pr1c4->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr1c4->setFlat(false);
                }
            }
            if(riga_attiva==2){
                if(rossi==1){
                    ui->pr2c1->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr2c1->setFlat(false);
                }
                if(rossi==2){
                    ui->pr2c2->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr2c2->setFlat(false);
                }
                if(rossi==3){
                    ui->pr2c3->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr2c3->setFlat(false);
                }
                if(rossi==4){
                    ui->pr2c4->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr2c4->setFlat(false);
                }
            }
            if(riga_attiva==3){
                if(rossi==1){
                    ui->pr3c1->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr3c1->setFlat(false);
                }
                if(rossi==2){
                    ui->pr3c2->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr3c2->setFlat(false);
                }
                if(rossi==3){
                    ui->pr3c3->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr3c3->setFlat(false);
                }
                if(rossi==4){
                    ui->pr3c4->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr3c4->setFlat(false);
                }
            }
            if(riga_attiva==4){
                if(rossi==1){
                    ui->pr4c1->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr4c1->setFlat(false);
                }
                if(rossi==2){
                    ui->pr4c2->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr4c2->setFlat(false);
                }
                if(rossi==3){
                    ui->pr4c3->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr4c3->setFlat(false);
                }
                if(rossi==4){
                    ui->pr4c4->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr4c4->setFlat(false);
                }
            }
            if(riga_attiva==5){
                if(rossi==1){
                    ui->pr5c1->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr5c1->setFlat(false);
                }
                if(rossi==2){
                    ui->pr5c2->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr5c2->setFlat(false);
                }
                if(rossi==3){
                    ui->pr5c3->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr5c3->setFlat(false);
                }
                if(rossi==4){
                    ui->pr5c4->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr5c4->setFlat(false);
                }
            }
        }
    }

}

bool vinto(){
    for(int x = 0; x<4;x++){
        if(combinazione[x]!=combinazione_vincente[x]){
            return false;
        }
    }
    return true;
}

void Gioco::on_checkl_clicked()
{
    if(riga_piena()){
        if(vinto()){
            auto v = new livello2;
            v->show();
            close();
        }
        if(riga_attiva<5){
            pallini();
            riga_attiva++;
        }
        else if(riga_attiva==5){
            auto p = new Perso;
            p->show();
            close();
        }
    }
}




void Gioco::on_pr1c1_clicked()
{
    return;
}

