#include "livello2.h"
#include "gioco.h"
#include "perso.h"
#include "ui_livello2.h"
#include "vinto.h"
#include <string>
#include <iostream>
using namespace std;
int pianeta2;
int riga_attiva2= 1;
int combinazione2[5] = {-1,-1,-1,-1,-1};
int numeri2[5] = {1,2,3,4,5};
int combinazione_vincente2[5];

void crea_comb2(){
    int x = 0;
    srand(time(NULL));
    while(x<5){

        int n = rand()%5;

        if(numeri2[n]!=-1){
            cout<<numeri2[n]<<endl;
            combinazione_vincente2[x] = numeri2[n];
            numeri2[n] = -1;
            x++;

        }
    }
}

livello2::livello2(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::livello2)
{
    ui->setupUi(this);
    crea_comb2();
}

livello2::~livello2()
{
    delete ui;
}





void livello2::on_p_1_clicked()
{
    pianeta2 = 1;
}

void livello2::on_p_2_clicked()
{
    pianeta2 = 2;
}


void livello2::on_p_3_clicked()
{
    pianeta2 =3;
}


void livello2::on_p_4_clicked()
{
    pianeta2 =4;
}

void livello2::on_r1c1_clicked()
{
    if(riga_attiva2==1){
        ui->r1c1->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[0]=pianeta2;
}


void livello2::on_r1c2_clicked()
{
    if(riga_attiva2==1){
        ui->r1c2->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[1]=pianeta2;
}


void livello2::on_r1c3_clicked()
{
    if(riga_attiva2==1){
        ui->r1c3->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[2]=pianeta2;
}


void livello2::on_r1c4_clicked()
{
    if(riga_attiva2==1){
        ui->r1c4->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[3]=pianeta2;
}


void livello2::on_r2c1_clicked()
{
    if(riga_attiva2==2){
        ui->r2c1->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[0]=pianeta2;
}


void livello2::on_r2c2_clicked()
{
    if(riga_attiva2==2){
        ui->r2c2->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[1]=pianeta2;
}


void livello2::on_r2c3_clicked()
{
    if(riga_attiva2==2){
        ui->r2c3->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[2]=pianeta2;
}


void livello2::on_r2c4_clicked()
{
    if(riga_attiva2==2){
        ui->r2c4->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[3]=pianeta2;
}


void livello2::on_r3c1_clicked()
{
    if(riga_attiva2==3){
        ui->r3c1->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[0]=pianeta2;
}


void livello2::on_r3c2_clicked()
{
    if(riga_attiva2==3){
        ui->r3c2->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[1]=pianeta2;
}


void livello2::on_r3c3_clicked()
{
    if(riga_attiva2==3){
        ui->r3c3->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[2]=pianeta2;
}


void livello2::on_r3c4_clicked()
{
    if(riga_attiva2==3){
        ui->r3c4->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[3]=pianeta2;
}


void livello2::on_r4c1_clicked()
{
    if(riga_attiva2==4){
        ui->r4c1->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[0]=pianeta2;
}


void livello2::on_r4c2_clicked()
{
    if(riga_attiva2==4){
        ui->r4c2->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[1]=pianeta2;
}


void livello2::on_r4c3_clicked()
{
    if(riga_attiva2==4){
        ui->r4c3->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[2]=pianeta2;
}


void livello2::on_r4c4_clicked()
{
    if(riga_attiva2==4){
        ui->r4c4->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[3]=pianeta2;
}


void livello2::on_r5c1_clicked()
{
    if(riga_attiva2==5){
        ui->r5c1->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[0]=pianeta2;
}


void livello2::on_r5c2_clicked()
{
    if(riga_attiva2==5){
        ui->r5c2->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[1]=pianeta2;
}


void livello2::on_r5c3_clicked()
{
    if(riga_attiva2==5){
        ui->r5c3->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[2]=pianeta2;
}


void livello2::on_r5c4_clicked()
{
    if(riga_attiva2==5){
        ui->r5c4->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[3]=pianeta2;
}



void livello2::pallini(){
    int rossi = 0;
    for(int x=0;x<4;x++){

        if(combinazione2[x]==combinazione_vincente2[x]){
            rossi+=1;
            if(riga_attiva2==1){
                if(rossi==1){
                    ui->pr1c1->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr1c1->setFlat(false);
                }
                if(rossi==2){
                    ui->pr1c2->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr1c2->setFlat(false);
                }
                if(rossi==3){
                    ui->pr1c3->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr1c3->setFlat(false);
                }
                if(rossi==4){
                    ui->pr1c4->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr1c4->setFlat(false);
                }
            }
            if(riga_attiva2==2){
                if(rossi==1){
                    ui->pr2c1->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr2c1->setFlat(false);
                }
                if(rossi==2){
                    ui->pr2c2->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr2c2->setFlat(false);
                }
                if(rossi==3){
                    ui->pr2c3->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr2c3->setFlat(false);
                }
                if(rossi==4){
                    ui->pr2c4->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr2c4->setFlat(false);
                }
            }
            if(riga_attiva2==3){
                if(rossi==1){
                    ui->pr3c1->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr3c1->setFlat(false);
                }
                if(rossi==2){
                    ui->pr3c2->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr3c2->setFlat(false);
                }
                if(rossi==3){
                    ui->pr3c3->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr3c3->setFlat(false);
                }
                if(rossi==4){
                    ui->pr3c4->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr3c4->setFlat(false);
                }
            }
            if(riga_attiva2==4){
                if(rossi==1){
                    ui->pr4c1->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr4c1->setFlat(false);
                }
                if(rossi==2){
                    ui->pr4c2->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr4c2->setFlat(false);
                }
                if(rossi==3){
                    ui->pr4c3->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr4c3->setFlat(false);
                }
                if(rossi==4){
                    ui->pr4c4->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr4c4->setFlat(false);
                }
            }
            if(riga_attiva2==5){
                if(rossi==1){
                    ui->pr5c1->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr5c1->setFlat(false);
                }
                if(rossi==2){
                    ui->pr5c2->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr5c2->setFlat(false);
                }
                if(rossi==3){
                    ui->pr5c3->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr5c3->setFlat(false);
                }
                if(rossi==4){
                    ui->pr5c4->setStyleSheet("border-image: url(:/textures/red.png);");
                    ui->pr5c4->setFlat(false);
                }
            }
        }
    }

}

bool vinto2(){
    for(int x = 0; x<5;x++){
        if(combinazione2[x]!=combinazione_vincente2[x]){
            return false;
        }
    }
    return true;
}

bool riga_piena2(){
    for(int x=0;x<5;x++){
        if(combinazione2[x]==-1){
            return false;
        }
    }
    return true;
}

void livello2::on_checkl_clicked()
{
    if(riga_piena2()){
        if(vinto2()){
            auto v = new class vinto;
            v->show();
            close();
        }
        if(riga_attiva2<5){
            pallini();
            riga_attiva2++;
        }
        else if(riga_attiva2==5){
            auto p = new Perso;
            p->show();
            close();
        }
    }
}




void livello2::on_pr1c1_clicked()
{
    return;
}

void livello2::on_r1c5_clicked()
{
    if(riga_attiva2==1){
        ui->r1c5->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[4]=pianeta2;
}


void livello2::on_r2c5_clicked()
{
    if(riga_attiva2==2){
        ui->r2c5->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[4]=pianeta2;
}


void livello2::on_r3c5_clicked()
{
    if(riga_attiva2==3){
        ui->r3c5->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[4]=pianeta2;
}


void livello2::on_r4c5_clicked()
{
    if(riga_attiva2==4){
        ui->r4c5->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[4]=pianeta2;
}


void livello2::on_r5c5_clicked()
{
    if(riga_attiva2==5){
        ui->r5c5->setStyleSheet(QString::fromStdString("border-image: url(:/textures/"+to_string(pianeta2)+".png);"));
    }
    combinazione2[4]=pianeta2;
}


void livello2::on_indietro_clicked()
{
    auto g = new Gioco;
    g->show();
    close();
}


void livello2::on_p_5_clicked()
{
    pianeta2=5;
}

