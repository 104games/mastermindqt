#ifndef REGOLE_H
#define REGOLE_H

#include <QWidget>

namespace Ui {
class Regole;
}

class Regole : public QWidget
{
    Q_OBJECT

public:
    explicit Regole(QWidget *parent = nullptr);
    ~Regole();

private slots:
    void on_pushButton_clicked();

    void on_gioca_clicked();

private:
    Ui::Regole *ui;
};

#endif // REGOLE_H
