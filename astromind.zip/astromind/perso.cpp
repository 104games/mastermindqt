#include "perso.h"
#include "gioco.h"
#include "mainwindow.h"
#include "ui_perso.h"

Perso::Perso(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Perso)
{
    ui->setupUi(this);
}

Perso::~Perso()
{
    delete ui;
}

void Perso::on_indietro_clicked()
{
    auto m = new MainWindow;
    m->show();
    close();
}


void Perso::on_gioca_clicked()
{
    auto g = new Gioco;
    g->show();
    close();
}


