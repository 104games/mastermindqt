#include "mainwindow.h"
#include "gioco.h"
#include "regole.h"
#include "storia.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    auto r = new Regole;
    r->show();
    close();
}


void MainWindow::on_gioca_clicked()
{
    auto g = new Gioco;
    g->show();
    close();
}


void MainWindow::on_storia_clicked()
{
    auto s = new Storia;
    s->show();
    close();
}

