#ifndef LIVELLO2_H
#define LIVELLO2_H

#include <QWidget>

namespace Ui {
class livello2;
}

class livello2 : public QWidget
{
    Q_OBJECT

public:
    explicit livello2(QWidget *parent = nullptr);
    ~livello2();

private slots:
    void on_r1c5_clicked();

    void on_r1c1_clicked();

    void on_p_4_clicked();

    void on_p_1_clicked();

    void on_p_2_clicked();

    void on_p_3_clicked();

    void on_r1c2_clicked();

    void on_r1c3_clicked();

    void on_r1c4_clicked();

    void on_r2c1_clicked();

    void on_r2c2_clicked();

    void on_r2c3_clicked();

    void on_r2c4_clicked();

    void on_r2c5_clicked();

    void on_r3c1_clicked();

    void on_r3c2_clicked();

    void on_r3c3_clicked();

    void on_r3c4_clicked();

    void on_r3c5_clicked();

    void on_r4c1_clicked();

    void on_r4c2_clicked();

    void on_r4c3_clicked();

    void on_r4c4_clicked();

    void on_r4c5_clicked();

    void on_r5c1_clicked();

    void on_r5c2_clicked();

    void on_r5c3_clicked();

    void on_r5c4_clicked();

    void on_r5c5_clicked();

    void on_pr1c1_clicked();

    void on_checkl_clicked();

    void on_indietro_clicked();

    void on_p_5_clicked();

private:
    Ui::livello2 *ui;
    void pallini();
};

#endif // LIVELLO2_H
