#ifndef STORIA_H
#define STORIA_H

#include <QWidget>

namespace Ui {
class Storia;
}

class Storia : public QWidget
{
    Q_OBJECT

public:
    explicit Storia(QWidget *parent = nullptr);
    ~Storia();

private slots:
    void on_gioca_clicked();

    void on_indietro_clicked();

private:
    Ui::Storia *ui;
};

#endif // STORIA_H
