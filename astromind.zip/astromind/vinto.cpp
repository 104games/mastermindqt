#include "vinto.h"
#include "gioco.h"
#include "mainwindow.h"
#include "ui_vinto.h"

vinto::vinto(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::vinto)
{
    ui->setupUi(this);
}

vinto::~vinto()
{
    delete ui;
}

void vinto::on_indietro_clicked()
{
    auto m = new MainWindow;
    m->show();
    close();
}


void vinto::on_gioca_clicked()
{
    auto g = new Gioco;
    g->show();
    close();
}

