#ifndef PERSO_H
#define PERSO_H

#include <QWidget>

namespace Ui {
class Perso;
}

class Perso : public QWidget
{
    Q_OBJECT

public:
    explicit Perso(QWidget *parent = nullptr);
    ~Perso();

private slots:
    void on_indietro_clicked();

    void on_gioca_clicked();

private:
    Ui::Perso *ui;
};

#endif // PERSO_H
