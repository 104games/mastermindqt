#ifndef VINTO_H
#define VINTO_H

#include <QWidget>

namespace Ui {
class vinto;
}

class vinto : public QWidget
{
    Q_OBJECT

public:
    explicit vinto(QWidget *parent = nullptr);
    ~vinto();

private slots:
    void on_indietro_clicked();

    void on_gioca_clicked();

private:
    Ui::vinto *ui;
};

#endif // VINTO_H
