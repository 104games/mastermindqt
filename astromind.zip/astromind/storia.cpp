#include "storia.h"
#include "gioco.h"
#include "mainwindow.h"
#include "ui_storia.h"

Storia::Storia(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Storia)
{
    ui->setupUi(this);
}

Storia::~Storia()
{
    delete ui;
}

void Storia::on_gioca_clicked()
{
    auto g = new Gioco;
    g->show();
    close();
}


void Storia::on_indietro_clicked()
{
    auto m = new MainWindow;
    m->show();
    close();
}

