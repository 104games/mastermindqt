#include "regole.h"
#include "ui_regole.h"
#include "mainwindow.h"
#include "gioco.h"
Regole::Regole(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Regole)
{
    ui->setupUi(this);
}

Regole::~Regole()
{
    delete ui;
}

void Regole::on_pushButton_clicked()
{
    auto m = new MainWindow;
    m->show();
    close();
}


void Regole::on_gioca_clicked()
{
    auto g = new Gioco;
    g->show();
    close();
}

