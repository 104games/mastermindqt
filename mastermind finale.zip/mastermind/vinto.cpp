#include "vinto.h"
#include "ui_vinto.h"
#include "mainwindow.h"
#include <string>

vinto::vinto(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::vinto)
{
    ui->setupUi(this);
}

vinto::~vinto()
{
    delete ui;
}

void vinto::passa_punteggio(int p){
    ui->textBrowser_2->setText(QString::fromStdString("punteggio: "+std::to_string(p)));
}

void vinto::on_conferma_2_clicked()
{
    auto m = new MainWindow;
    m->show();
    close();
}


void vinto::on_conferma_clicked()
{
    close();
}

