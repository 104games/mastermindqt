#include "perso.h"
#include "mainwindow.h"
#include "ui_perso.h"

perso::perso(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::perso)
{
    ui->setupUi(this);
}

perso::~perso()
{
    delete ui;
}

void perso::on_conferma_2_clicked()
{
    auto m = new MainWindow;
    m->show();
    close();
}


void perso::on_conferma_clicked()
{
    close();
}

