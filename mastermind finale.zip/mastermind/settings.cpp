#include "settings.h"
#include "ui_settings.h"
#include "mainwindow.h"
#include <iostream>
#include <fstream>
using namespace std;
settings::settings(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::settings)
{
    ui->setupUi(this);
}

settings::~settings()
{
    delete ui;
}

void settings::on_play_2_clicked()
{
    auto sett = new MainWindow;
    sett->show();
    close();
}


void settings::on_play_clicked()
{

    ofstream fout ("settings.txt");
    fout << ui->colori->text().toUtf8().toStdString() << endl;
    fout << ui->comb->text().toUtf8().toStdString() << endl;
    fout << ui->tent->text().toUtf8().toStdString() << endl;
    fout << ui->duplicati->isChecked() << endl;
    fout.close();

}

