#ifndef GAME_H
#define GAME_H

#include <QWidget>
#include <vector>
namespace Ui {
class game;
}

class game : public QWidget
{
    Q_OBJECT

public:
    explicit game(QWidget *parent = nullptr);
    ~game();

private slots:
    void on_rosso_clicked();

private:
    Ui::game *ui;
    int colori;
    int comb;
    int tent;
    bool dup;

    std::string colore;

    std::string all_colori[10] = {"rosso","blu","verde","giallo","rosa","viola","marrone","azzurro","arancione","grigio"};

    std::vector<std::string> combinazione;

    //funzioni
    void setup();
    void disattiva_colonna();
    void attiva_colonna(int num);
    std::vector<std::string> genera_combinazione();


};

#endif // GAME_H
