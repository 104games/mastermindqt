#include "game.h"
#include "ui_game.h"
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;








game::game(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::game)
{


    ui->setupUi(this);
    ifstream fin("settings.txt");
    fin>> colori;
    fin>> comb;
    fin>> tent;
    fin>> dup;

    fin.close();

    setup();
}

game::~game()
{
    delete ui;
}







void game::on_rosso_clicked()
{
    colore = "rosso";
    cout << colore;
}
























vector<string> game::genera_combinazione(){
    vector<string> ris;
    string col[colori];
    srand(time(NULL));
    for(int x = 0; x<colori; x++){
        col[x] = all_colori[x];
    }

    while (ris.size()<comb){
        int x = rand()%comb;
        if(col[x]!="x"){
            ris.push_back(col[x]);
            if(dup==false){
                col[x] = "x";
            }
        }
    }
    return ris;

}
// setup
void game::setup(){

    for(int x=colori;x<10;x++){
        if(all_colori[x]=="rosa"){ui->rosa->hide();}
        if(all_colori[x]=="viola"){ui->viola->hide();}
        if(all_colori[x]=="marrone"){ui->marrone->hide();}
        if(all_colori[x]=="azzurro"){ui->azzurro->hide();}
        if(all_colori[x]=="arancione"){ui->arancione->hide();}
        if(all_colori[x]=="grigio"){ui->grigio->hide();}
    }


    disattiva_colonna();


    ui->r2c1->hide();
    ui->r2c2->hide();
    ui->r2c3->hide();
    ui->r2c4->hide();
    ui->r2c5->hide();
    ui->r2c6->hide();
    ui->r2c7->hide();
    ui->r2c8->hide();
    ui->r2c9->hide();
    ui->r2c10->hide();

    ui->r3c1->hide();
    ui->r3c2->hide();
    ui->r3c3->hide();
    ui->r3c4->hide();
    ui->r3c5->hide();
    ui->r3c6->hide();
    ui->r3c7->hide();
    ui->r3c8->hide();
    ui->r3c9->hide();
    ui->r3c10->hide();

    ui->r4c1->hide();
    ui->r4c2->hide();
    ui->r4c3->hide();
    ui->r4c4->hide();
    ui->r4c5->hide();
    ui->r4c6->hide();
    ui->r4c7->hide();
    ui->r4c8->hide();
    ui->r4c9->hide();
    ui->r4c10->hide();

    ui->r5c1->hide();
    ui->r5c2->hide();
    ui->r5c3->hide();
    ui->r5c4->hide();
    ui->r5c5->hide();
    ui->r5c6->hide();
    ui->r5c7->hide();
    ui->r5c8->hide();
    ui->r5c9->hide();
    ui->r5c10->hide();

    ui->r6c1->hide();
    ui->r6c2->hide();
    ui->r6c3->hide();
    ui->r6c4->hide();
    ui->r6c5->hide();
    ui->r6c6->hide();
    ui->r6c7->hide();
    ui->r6c8->hide();
    ui->r6c9->hide();
    ui->r6c10->hide();

    ui->r7c1->hide();
    ui->r7c2->hide();
    ui->r7c3->hide();
    ui->r7c4->hide();
    ui->r7c5->hide();
    ui->r7c6->hide();
    ui->r7c7->hide();
    ui->r7c8->hide();
    ui->r7c9->hide();
    ui->r7c10->hide();

    ui->r8c1->hide();
    ui->r8c2->hide();
    ui->r8c3->hide();
    ui->r8c4->hide();
    ui->r8c5->hide();
    ui->r8c6->hide();
    ui->r8c7->hide();
    ui->r8c8->hide();
    ui->r8c9->hide();
    ui->r8c10->hide();

    ui->r9c1->hide();
    ui->r9c2->hide();
    ui->r9c3->hide();
    ui->r9c4->hide();
    ui->r9c5->hide();
    ui->r9c6->hide();
    ui->r9c7->hide();
    ui->r9c8->hide();
    ui->r9c9->hide();
    ui->r9c10->hide();

    ui->r10c1->hide();
    ui->r10c2->hide();
    ui->r10c3->hide();
    ui->r10c4->hide();
    ui->r10c5->hide();
    ui->r10c6->hide();
    ui->r10c7->hide();
    ui->r10c8->hide();
    ui->r10c9->hide();
    ui->r10c10->hide();

    combinazione = genera_combinazione();
    attiva_colonna(3);
}

void game::attiva_colonna(int num){
    if(num == 2){
        ui->r2c1->show();
        ui->r2c2->show();
        ui->r2c3->show();
        ui->r2c4->show();
        ui->r2c5->show();
        ui->r2c6->show();
        ui->r2c7->show();
        ui->r2c8->show();
        ui->r2c9->show();
        ui->r2c10->show();
    }
    if(num == 3){
        ui->r3c1->show();
        ui->r3c2->show();
        ui->r3c3->show();
        ui->r3c4->show();
        ui->r3c5->show();
        ui->r3c6->show();
        ui->r3c7->show();
        ui->r3c8->show();
        ui->r3c9->show();
        ui->r3c10->show();
    }
    if(num == 4){
        ui->r4c1->show();
        ui->r4c2->show();
        ui->r4c3->show();
        ui->r4c4->show();
        ui->r5c5->show();
        ui->r6c6->show();
        ui->r7c7->show();
        ui->r8c8->show();
        ui->r9c9->show();
        ui->r10c10->show();
    }
    if(num == 5){
        ui->r5c1->show();
        ui->r5c2->show();
        ui->r5c3->show();
        ui->r5c4->show();
        ui->r5c5->show();
        ui->r5c6->show();
        ui->r5c7->show();
        ui->r5c8->show();
        ui->r5c9->show();
        ui->r5c10->show();
    }
    if(num == 6){
        ui->r6c1->show();
        ui->r6c2->show();
        ui->r6c3->show();
        ui->r6c4->show();
        ui->r6c5->show();
        ui->r6c6->show();
        ui->r6c7->show();
        ui->r6c8->show();
        ui->r6c9->show();
        ui->r6c10->show();
    }
    if(num == 7){
        ui->r7c1->show();
        ui->r7c2->show();
        ui->r7c3->show();
        ui->r7c4->show();
        ui->r7c5->show();
        ui->r7c6->show();
        ui->r7c7->show();
        ui->r7c8->show();
        ui->r7c9->show();
        ui->r7c10->show();
    }
    if(num == 8){
        ui->r8c1->show();
        ui->r8c2->show();
        ui->r8c3->show();
        ui->r8c4->show();
        ui->r8c5->show();
        ui->r8c6->show();
        ui->r8c7->show();
        ui->r8c8->show();
        ui->r8c9->show();
        ui->r8c10->show();
    }
    if(num == 9){
        ui->r9c1->show();
        ui->r9c2->show();
        ui->r9c3->show();
        ui->r9c4->show();
        ui->r9c5->show();
        ui->r9c6->show();
        ui->r9c7->show();
        ui->r9c8->show();
        ui->r9c9->show();
        ui->r9c10->show();
    }
    if(num == 10){
        ui->r10c1->show();
        ui->r10c2->show();
        ui->r10c3->show();
        ui->r10c4->show();
        ui->r10c5->show();
        ui->r10c6->show();
        ui->r10c7->show();
        ui->r10c8->show();
        ui->r10c9->show();
        ui->r10c10->show();
    }
    disattiva_colonna();

}

void game::disattiva_colonna(){

    if(comb==4){
        ui->r1c1->close();
        ui->r2c1->close();
        ui->r3c1->close();
        ui->r4c1->close();
        ui->r5c1->close();
        ui->r6c1->close();
        ui->r7c1->close();
        ui->r8c1->close();
        ui->r9c1->close();
        ui->r10c1->close();

        ui->r1c2->close();
        ui->r2c2->close();
        ui->r3c2->close();
        ui->r4c2->close();
        ui->r5c2->close();
        ui->r6c2->close();
        ui->r7c2->close();
        ui->r8c2->close();
        ui->r9c2->close();
        ui->r10c2->close();

        ui->r1c3->close();
        ui->r2c3->close();
        ui->r3c3->close();
        ui->r4c3->close();
        ui->r5c3->close();
        ui->r6c3->close();
        ui->r7c3->close();
        ui->r8c3->close();
        ui->r9c3->close();
        ui->r10c3->close();

        ui->r1c8->close();
        ui->r2c8->close();
        ui->r3c8->close();
        ui->r4c8->close();
        ui->r5c8->close();
        ui->r6c8->close();
        ui->r7c8->close();
        ui->r8c8->close();
        ui->r9c8->close();
        ui->r10c8->close();

        ui->r1c9->close();
        ui->r2c9->close();
        ui->r3c9->close();
        ui->r4c9->close();
        ui->r5c9->close();
        ui->r6c9->close();
        ui->r7c9->close();
        ui->r8c9->close();
        ui->r9c9->close();
        ui->r10c9->close();

        ui->r1c10->close();
        ui->r2c10->close();
        ui->r3c10->close();
        ui->r4c10->close();
        ui->r5c10->close();
        ui->r6c10->close();
        ui->r7c10->close();
        ui->r8c10->close();
        ui->r9c10->close();
        ui->r10c10->close();
    }
    if(comb==5){
        ui->r1c1->close();
        ui->r2c1->close();
        ui->r3c1->close();
        ui->r4c1->close();
        ui->r5c1->close();
        ui->r6c1->close();
        ui->r7c1->close();
        ui->r8c1->close();
        ui->r9c1->close();
        ui->r10c1->close();

        ui->r1c2->close();
        ui->r2c2->close();
        ui->r3c2->close();
        ui->r4c2->close();
        ui->r5c2->close();
        ui->r6c2->close();
        ui->r7c2->close();
        ui->r8c2->close();
        ui->r9c2->close();
        ui->r10c2->close();

        ui->r1c8->close();
        ui->r2c8->close();
        ui->r3c8->close();
        ui->r4c8->close();
        ui->r5c8->close();
        ui->r6c8->close();
        ui->r7c8->close();
        ui->r8c8->close();
        ui->r9c8->close();
        ui->r10c8->close();

        ui->r1c9->close();
        ui->r2c9->close();
        ui->r3c9->close();
        ui->r4c9->close();
        ui->r5c9->close();
        ui->r6c9->close();
        ui->r7c9->close();
        ui->r8c9->close();
        ui->r9c9->close();
        ui->r10c9->close();

        ui->r1c10->close();
        ui->r2c10->close();
        ui->r3c10->close();
        ui->r4c10->close();
        ui->r5c10->close();
        ui->r6c10->close();
        ui->r7c10->close();
        ui->r8c10->close();
        ui->r9c10->close();
        ui->r10c10->close();
    }

    if(comb==6){
        ui->r1c1->close();
        ui->r2c1->close();
        ui->r3c1->close();
        ui->r4c1->close();
        ui->r5c1->close();
        ui->r6c1->close();
        ui->r7c1->close();
        ui->r8c1->close();
        ui->r9c1->close();
        ui->r10c1->close();

        ui->r1c2->close();
        ui->r2c2->close();
        ui->r3c2->close();
        ui->r4c2->close();
        ui->r5c2->close();
        ui->r6c2->close();
        ui->r7c2->close();
        ui->r8c2->close();
        ui->r9c2->close();
        ui->r10c2->close();

        ui->r1c9->close();
        ui->r2c9->close();
        ui->r3c9->close();
        ui->r4c9->close();
        ui->r5c9->close();
        ui->r6c9->close();
        ui->r7c9->close();
        ui->r8c9->close();
        ui->r9c9->close();
        ui->r10c9->close();

        ui->r1c10->close();
        ui->r2c10->close();
        ui->r3c10->close();
        ui->r4c10->close();
        ui->r5c10->close();
        ui->r6c10->close();
        ui->r7c10->close();
        ui->r8c10->close();
        ui->r9c10->close();
        ui->r10c10->close();
    }

    if(comb==7){
        ui->r1c1->close();
        ui->r2c1->close();
        ui->r3c1->close();
        ui->r4c1->close();
        ui->r5c1->close();
        ui->r6c1->close();
        ui->r7c1->close();
        ui->r8c1->close();
        ui->r9c1->close();
        ui->r10c1->close();

        ui->r1c9->close();
        ui->r2c9->close();
        ui->r3c9->close();
        ui->r4c9->close();
        ui->r5c9->close();
        ui->r6c9->close();
        ui->r7c9->close();
        ui->r8c9->close();
        ui->r9c9->close();
        ui->r10c9->close();

        ui->r1c10->close();
        ui->r2c10->close();
        ui->r3c10->close();
        ui->r4c10->close();
        ui->r5c10->close();
        ui->r6c10->close();
        ui->r7c10->close();
        ui->r8c10->close();
        ui->r9c10->close();
        ui->r10c10->close();
    }
    if(comb==8){
        ui->r1c1->close();
        ui->r2c1->close();
        ui->r3c1->close();
        ui->r4c1->close();
        ui->r5c1->close();
        ui->r6c1->close();
        ui->r7c1->close();
        ui->r8c1->close();
        ui->r9c1->close();
        ui->r10c1->close();

        ui->r1c10->close();
        ui->r2c10->close();
        ui->r3c10->close();
        ui->r4c10->close();
        ui->r5c10->close();
        ui->r6c10->close();
        ui->r7c10->close();
        ui->r8c10->close();
        ui->r9c10->close();
        ui->r10c10->close();
    }
    if(comb==9){
        ui->r1c10->close();
        ui->r2c10->close();
        ui->r3c10->close();
        ui->r4c10->close();
        ui->r5c10->close();
        ui->r6c10->close();
        ui->r7c10->close();
        ui->r8c10->close();
        ui->r9c10->close();
        ui->r10c10->close();
    }

}
