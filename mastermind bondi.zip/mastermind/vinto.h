#ifndef VINTO_H
#define VINTO_H

#include <QWidget>

namespace Ui {
class vinto;
}

class vinto : public QWidget
{
    Q_OBJECT

public:
    explicit vinto(QWidget *parent = nullptr);
    ~vinto();
    void passa_punteggio(int p);

private slots:
    void on_conferma_2_clicked();

    void on_conferma_clicked();

private:
    Ui::vinto *ui;



};

#endif // VINTO_H
