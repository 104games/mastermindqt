#ifndef PERSO_H
#define PERSO_H

#include <QWidget>

namespace Ui {
class perso;
}

class perso : public QWidget
{
    Q_OBJECT

public:
    explicit perso(QWidget *parent = nullptr);
    ~perso();

private slots:
    void on_conferma_2_clicked();

    void on_conferma_clicked();

private:
    Ui::perso *ui;
};

#endif // PERSO_H
