#include "game.h"
#include "perso.h"
#include "ui_game.h"
#include "vinto.h"
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string.h>

using namespace std;



game::game(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::game)
{


    ui->setupUi(this);
    ifstream fin("settings.txt");
    fin>> colori;
    fin>> comb;
    fin>> tent;
    fin>> dup;

    fin.close();

    setup();
}

game::~game()
{
    delete ui;
}


int game::trasforma_colonna_in_pos(int x){
    if(comb==4){
        return x-4;
    }
    if(comb==5){
        return x-3;
    }
    if(comb==6){
        return x-3;
    }
    if(comb==7){
        return x-2;
    }
    if(comb==8){
        return x-2;
    }
    return x-1;
}


void game::scelta(int pos){
    selezionate[pos] = colore;
}

void game::leggi_punteggi(){
    ifstream fin("punteggi.txt");
    int n;
    int max = 0;
    for(int x=0;x<n;x++){
        int p;
        fin>>p;
        if(p>max){
            max = p;
        }
        punteggi.push_back(p);
    }
    hs=max;
    ui->hs->setText(QString::fromStdString(to_string(hs)));
}

void game::salva_punteggio(){
    ifstream fin("punteggi.txt");
    int n;
    fin>>n;
    fin.close();
    ofstream fout ("punteggi.txt");
    for(int x=0;x<n;x++){
        fout<<punteggi[x]<<endl;
    }
    fout.close();
}

bool game::riga_piena(){
    for(int x=0; x<colori; x++){

        if(selezionate[x]==""){

            return false;
        }
    }
    return true;
}

vector<string> game::genera_combinazione(){
    vector<string> ris;
    string col[colori];
    srand(time(NULL));
    for(int x = 0; x<colori; x++){
        col[x] = all_colori[x];
    }

    for(int x=0;x<comb;x++){
        selezionate.push_back("");

    }

    while (ris.size()<comb){
        int x = rand()%comb;
        if(col[x]!="x"){
            ris.push_back(col[x]);
            cout<<col[x]<< " " <<endl;
            if(dup==false){
                col[x] = "x";
            }
        }
    }
    return ris;

}

bool check_giallo(string el, vector<string> vec, int n){
    for(int x=0;x<n;x++){
        if(el==vec[x]){
            return true;
        }
    }
    return false;
}

void game::riempi_pallini(){
    int pezzi[2];
    pezzi[0]=0;
    pezzi[1]=0;
    //check rossi
    for(int x=0;x<comb;x++){
        if(selezionate[x]==combinazione[x]){
            pezzi[0]+=1;
            selezionate[x]="";
        }
    }
    for(int x=0;x<comb;x++){
        if(check_giallo(selezionate[x],combinazione, comb)){
            pezzi[1]+=1;
        }
    }
    cout<<pezzi[0]<< " " << pezzi[1] << endl;
    if(pezzi[0]+pezzi[1]>0){
        for(int x=0;x<=(pezzi[0]+pezzi[1]);x++){
            if(x<=pezzi[0]){
                if(x==1){
                    if(riga_attiva==1){
                        ui->pr1n1->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr1n1->show();
                    }
                    if(riga_attiva==2){
                        ui->pr2n1->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr2n1->show();
                    }
                    if(riga_attiva==3){
                        ui->pr3n1->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr3n1->show();
                    }
                    if(riga_attiva==4){
                        ui->pr4n1->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr4n1->show();
                    }
                    if(riga_attiva==5){
                        ui->pr5n1->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr5n1->show();
                    }



                }
                if(x==2){
                    if(riga_attiva==1){
                        ui->pr1n2->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr1n2->show();
                    }
                    if(riga_attiva==2){
                        ui->pr2n2->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr2n2->show();
                    }
                    if(riga_attiva==3){
                        ui->pr3n2->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr3n2->show();
                    }
                    if(riga_attiva==4){
                        ui->pr4n2->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr4n2->show();
                    }
                    if(riga_attiva==5){
                        ui->pr5n2->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr5n2->show();
                    }

                }
                if(x==3){

                    if(riga_attiva==1){
                        ui->pr1n3->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr1n3->show();
                    }
                    if(riga_attiva==2){
                        ui->pr2n3->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr2n3->show();
                    }
                    if(riga_attiva==3){
                        ui->pr3n3->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr3n3->show();
                    }
                    if(riga_attiva==4){
                        ui->pr4n3->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr4n3->show();
                    }
                    if(riga_attiva==5){
                        ui->pr5n3->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr5n3->show();
                    }


                }
                if(x==4){
                    if(riga_attiva==1){
                        ui->pr1n4->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr1n4->show();
                    }
                    if(riga_attiva==2){
                        ui->pr2n4->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr2n4->show();
                    }
                    if(riga_attiva==3){
                        ui->pr3n4->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr3n4->show();
                    }
                    if(riga_attiva==4){
                        ui->pr4n4->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr4n4->show();
                    }
                    if(riga_attiva==5){
                        ui->pr5n4->setStyleSheet("border-image: url(:/colori/colori/rosso..png);");
                        ui->pr5n4->show();
                    }

                }


            }
            if(x>pezzi[0]){
                if(x==1){
                    if(riga_attiva==1){
                        ui->pr1n1->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr1n1->show();
                    }
                    if(riga_attiva==2){
                        ui->pr2n1->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr2n1->show();
                    }
                    if(riga_attiva==3){
                        ui->pr3n1->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr3n1->show();
                    }
                    if(riga_attiva==4){
                        ui->pr4n1->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr4n1->show();
                    }
                    if(riga_attiva==5){
                        ui->pr5n1->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr5n1->show();
                    }

                }
                if(x==2){
                    if(riga_attiva==1){
                        ui->pr1n2->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr1n2->show();
                    }
                    if(riga_attiva==2){
                        ui->pr2n2->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr2n2->show();
                    }
                    if(riga_attiva==3){
                        ui->pr3n2->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr3n2->show();
                    }
                    if(riga_attiva==4){
                        ui->pr4n2->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr4n2->show();
                    }
                    if(riga_attiva==5){
                        ui->pr5n2->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr5n2->show();
                    }

                }
                if(x==3){

                    if(riga_attiva==1){
                        ui->pr1n3->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr1n3->show();
                    }
                    if(riga_attiva==2){
                        ui->pr2n3->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr2n3->show();
                    }
                    if(riga_attiva==3){
                        ui->pr3n3->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr3n3->show();
                    }
                    if(riga_attiva==4){
                        ui->pr4n3->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr4n3->show();
                    }
                    if(riga_attiva==5){
                        ui->pr5n3->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr5n3->show();
                    }
                }
                if(x==4){
                    if(riga_attiva==1){
                        ui->pr1n4->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr1n4->show();
                    }
                    if(riga_attiva==2){
                        ui->pr2n4->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr2n4->show();
                    }
                    if(riga_attiva==3){
                        ui->pr3n4->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr3n4->show();
                    }
                    if(riga_attiva==4){
                        ui->pr4n4->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr4n4->show();
                    }
                    if(riga_attiva==5){
                        ui->pr5n4->setStyleSheet("border-image: url(:/colori/colori/bianco..png);");
                        ui->pr5n4->show();
                    }
                }

            }


        }
    }


}


bool game::vinto(){
    for(int x=0;x<comb;x++){
        if(selezionate[x]!=combinazione[x]){
            riempi_pallini();
            return false;
        }
    }
    return true;
}

// setup
void game::setup(){
    leggi_punteggi();


    disattiva_riga();


    ui->r2c1->hide();
    ui->r2c2->hide();
    ui->r2c3->hide();
    ui->r2c4->hide();


    ui->r3c1->hide();
    ui->r3c2->hide();
    ui->r3c3->hide();
    ui->r3c4->hide();


    ui->r4c1->hide();
    ui->r4c2->hide();
    ui->r4c3->hide();
    ui->r4c4->hide();


    ui->r5c1->hide();
    ui->r5c2->hide();
    ui->r5c3->hide();
    ui->r5c4->hide();






    ui->pr2n1->hide();
    ui->pr2n2->hide();
    ui->pr2n3->hide();
    ui->pr2n4->hide();


    ui->pr3n1->hide();
    ui->pr3n2->hide();
    ui->pr3n3->hide();
    ui->pr3n4->hide();

    ui->pr4n1->hide();
    ui->pr4n2->hide();
    ui->pr4n3->hide();
    ui->pr4n4->hide();


    ui->pr5n1->hide();
    ui->pr5n2->hide();
    ui->pr5n3->hide();
    ui->pr5n4->hide();





    combinazione = genera_combinazione();

}

void game::attiva_riga(int num){
    if(num == 2){
        ui->r2c1->show();
        ui->r2c2->show();
        ui->r2c3->show();
        ui->r2c4->show();

    }
    if(num == 3){
        ui->r3c1->show();
        ui->r3c2->show();
        ui->r3c3->show();
        ui->r3c4->show();

    }
    if(num == 4){
        ui->r4c1->show();
        ui->r4c2->show();
        ui->r4c3->show();
        ui->r4c4->show();

    }
    if(num == 5){
        ui->r5c1->show();
        ui->r5c2->show();
        ui->r5c3->show();
        ui->r5c4->show();

    }

    disattiva_riga();
    for(int x=0;x<comb;x++){
        selezionate[x]="";
    }

}

void game::disattiva_riga(){

    return;

}


//colori click
void game::on_rosso_clicked()
{
    colore = "rosso";
}
void game::on_blu_clicked()
{
    colore = "blu";
}
void game::on_verde_clicked()
{
    colore = "verde";
}
void game::on_giallo_clicked()
{
    colore = "giallo";
}
void game::on_rosa_clicked()
{
    colore = "rosa";
}
void game::on_viola_clicked()
{
    colore = "viola";
}
void game::on_marrone_clicked()
{
    colore = "marrone";
}
void game::on_azzurro_clicked()
{
    colore = "azzurro";
}
void game::on_arancione_clicked()
{
    colore = "arancione";
}
void game::on_grigio_clicked()
{
    colore = "grigio";
}

//spazio click
void game::on_r1c1_clicked()
{
    if(riga_attiva>1){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r1c1->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(1));
}
void game::on_r1c2_clicked()
{
    if(riga_attiva>1){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r1c2->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(2));
}
void game::on_r1c3_clicked()
{
    if(riga_attiva>1){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r1c3->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(3));
}
void game::on_r1c4_clicked()
{
    if(riga_attiva>1){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r1c4->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(4));
}
void game::on_r1c5_clicked()
{
    if(riga_attiva>1){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(5));
}
void game::on_r1c6_clicked()
{
    if(riga_attiva>1){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(6));
}
void game::on_r1c7_clicked()
{
    if(riga_attiva>1){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(7));
}
void game::on_r1c8_clicked()
{
    if(riga_attiva>1){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(8));
}
void game::on_r1c9_clicked()
{
    if(riga_attiva>1){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(9));
}
void game::on_r1c10_clicked()
{
    if(riga_attiva>1){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(10));
}

void game::on_r2c1_clicked()
{
    if(riga_attiva>2){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r2c1->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(1));
}
void game::on_r2c2_clicked()
{
    if(riga_attiva>2){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r2c2->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(2));
}
void game::on_r2c3_clicked()
{
    if(riga_attiva>2){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r2c3->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(3));
}
void game::on_r2c4_clicked()
{
    if(riga_attiva>2){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r2c4->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(4));
}
void game::on_r2c5_clicked()
{
    if(riga_attiva>2){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(5));
}
void game::on_r2c6_clicked()
{
    if(riga_attiva>2){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(6));
}
void game::on_r2c7_clicked()
{
    if(riga_attiva>2){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(7));
}
void game::on_r2c8_clicked()
{
    if(riga_attiva>2){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(8));
}
void game::on_r2c9_clicked()
{
    if(riga_attiva>2){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(9));
}
void game::on_r2c10_clicked()
{
    if(riga_attiva>2){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(10));
}

void game::on_r3c1_clicked()
{
    if(riga_attiva>3){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r3c1->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(1));
}
void game::on_r3c2_clicked()
{
    if(riga_attiva>3){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r3c2->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(2));
}
void game::on_r3c3_clicked()
{
    if(riga_attiva>3){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r3c3->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(3));
}
void game::on_r3c4_clicked()
{
    if(riga_attiva>3){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r3c4->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(4));
}
void game::on_r3c5_clicked()
{
    if(riga_attiva>3){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(5));
}
void game::on_r3c6_clicked()
{
    if(riga_attiva>3){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(6));
}
void game::on_r3c7_clicked()
{
    if(riga_attiva>3){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(7));
}
void game::on_r3c8_clicked()
{
    if(riga_attiva>3){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(8));
}
void game::on_r3c9_clicked()
{
    if(riga_attiva>3){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(9));
}
void game::on_r3c10_clicked()
{
    if(riga_attiva>3){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(10));
}

void game::on_r4c1_clicked()
{
    if(riga_attiva>4){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r4c1->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(1));
}
void game::on_r4c2_clicked()
{
    if(riga_attiva>4){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r4c2->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(2));
}
void game::on_r4c3_clicked()
{
    if(riga_attiva>4){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r4c3->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(3));
}
void game::on_r4c4_clicked()
{
    if(riga_attiva>4){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r4c4->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(4));
}
void game::on_r4c5_clicked()
{
    if(riga_attiva>4){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(5));
}
void game::on_r4c6_clicked()
{
    if(riga_attiva>4){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(6));
}
void game::on_r4c7_clicked()
{
    if(riga_attiva>4){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(7));
}
void game::on_r4c8_clicked()
{
    if(riga_attiva>4){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(8));
}
void game::on_r4c9_clicked()
{
    if(riga_attiva>4){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(9));
}
void game::on_r4c10_clicked()
{
    if(riga_attiva>4){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(10));
}

void game::on_r5c1_clicked()
{
    if(riga_attiva>5){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r5c1->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(1));
}
void game::on_r5c2_clicked()
{
    if(riga_attiva>5){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r5c2->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(2));
}
void game::on_r5c3_clicked()
{
    if(riga_attiva>5){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r5c3->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(3));
}
void game::on_r5c4_clicked()
{
    if(riga_attiva>5){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r5c4->setStyleSheet(QString::fromStdString(new_style));
    scelta(trasforma_colonna_in_pos(4));
}
void game::on_r5c5_clicked()
{
    if(riga_attiva>5){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(5));
}
void game::on_r5c6_clicked()
{
    if(riga_attiva>5){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(6));
}
void game::on_r5c7_clicked()
{
    if(riga_attiva>5){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(7));
}
void game::on_r5c8_clicked()
{
    if(riga_attiva>5){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(8));
}
void game::on_r5c9_clicked()
{
    if(riga_attiva>5){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(9));
}
void game::on_r5c10_clicked()
{
    if(riga_attiva>5){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(10));
}


void game::on_r6c1_clicked()
{
    if(riga_attiva>6){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(1));
}
void game::on_r6c2_clicked()
{
    if(riga_attiva>6){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(2));
}
void game::on_r6c3_clicked()
{
    if(riga_attiva>6){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(3));
}
void game::on_r6c4_clicked()
{
    if(riga_attiva>6){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(4));
}
void game::on_r6c5_clicked()
{
    if(riga_attiva>6){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(5));
}
void game::on_r6c6_clicked()
{
    if(riga_attiva>6){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(6));
}
void game::on_r6c7_clicked()
{
    if(riga_attiva>6){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(7));
}
void game::on_r6c8_clicked()
{
    if(riga_attiva>6){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(8));
}
void game::on_r6c9_clicked()
{
    if(riga_attiva>6){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ;
    scelta(trasforma_colonna_in_pos(9));
}
void game::on_r6c10_clicked()
{
    if(riga_attiva>6){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(10));
}

void game::on_r7c1_clicked()
{
    if(riga_attiva>7){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(1));
}
void game::on_r7c2_clicked()
{
    if(riga_attiva>7){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(2));
}
void game::on_r7c3_clicked()
{
    if(riga_attiva>7){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(3));
}
void game::on_r7c4_clicked()
{
    if(riga_attiva>7){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(4));
}
void game::on_r7c5_clicked()
{
    if(riga_attiva>7){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(5));
}
void game::on_r7c6_clicked()
{
    if(riga_attiva>7){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(6));
}
void game::on_r7c7_clicked()
{
    if(riga_attiva>7){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(7));
}
void game::on_r7c8_clicked()
{
    if(riga_attiva>7){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(8));
}
void game::on_r7c9_clicked()
{
    if(riga_attiva>7){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(9));
}
void game::on_r7c10_clicked()
{
    if(riga_attiva>7){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(10));
}

void game::on_r8c1_clicked()
{
    if(riga_attiva>8){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(1));
}
void game::on_r8c2_clicked()
{
    if(riga_attiva>8){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(2));
}
void game::on_r8c3_clicked()
{
    if(riga_attiva>8){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(3));
}
void game::on_r8c4_clicked()
{
    if(riga_attiva>8){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(4));
}
void game::on_r8c5_clicked()
{
    if(riga_attiva>8){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(5));
}
void game::on_r8c6_clicked()
{
    if(riga_attiva>8){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(6));
}
void game::on_r8c7_clicked()
{
    if(riga_attiva>8){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(7));
}
void game::on_r8c8_clicked()
{
    if(riga_attiva>8){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(8));
}
void game::on_r8c9_clicked()
{
    if(riga_attiva>8){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(9));
}
void game::on_r8c10_clicked()
{
    if(riga_attiva>8){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(10));
}

void game::on_r9c1_clicked()
{
    if(riga_attiva>9){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(1));
}
void game::on_r9c2_clicked()
{
    if(riga_attiva>9){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(2));
}
void game::on_r9c3_clicked()
{
    if(riga_attiva>9){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(3));
}
void game::on_r9c4_clicked()
{
    if(riga_attiva>9){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(4));
}
void game::on_r9c5_clicked()
{
    if(riga_attiva>9){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(5));
}
void game::on_r9c6_clicked()
{
    if(riga_attiva>9){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(6));
}
void game::on_r9c7_clicked()
{
    if(riga_attiva>9){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(7));
}
void game::on_r9c8_clicked()
{
    if(riga_attiva>9){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(8));
}
void game::on_r9c9_clicked()
{
    if(riga_attiva>9){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(9));
}
void game::on_r9c10_clicked()
{
    if(riga_attiva>9){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(10));
}


void game::on_r10c1_clicked()
{
    if(riga_attiva>10){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(1));
}
void game::on_r10c2_clicked()
{
    if(riga_attiva>10){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(2));
}
void game::on_r10c3_clicked()
{
    if(riga_attiva>10){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(3));
}
void game::on_r10c4_clicked()
{
    if(riga_attiva>10){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(4));
}
void game::on_r10c5_clicked()
{
    if(riga_attiva>10){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(5));
}
void game::on_r10c6_clicked()
{
    if(riga_attiva>10){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(6));
}
void game::on_r10c7_clicked()
{
    if(riga_attiva>10){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(7));
}
void game::on_r10c8_clicked()
{
    if(riga_attiva>10){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(8));
}
void game::on_r10c9_clicked()
{
    if(riga_attiva>10){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(9));
}
void game::on_r10c10_clicked()
{
    if(riga_attiva>10){
        return;
    }
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";

    scelta(trasforma_colonna_in_pos(10));
}




void game::on_conferma_clicked()
{

    if(riga_piena()){


        if(riga_attiva == tent){
            auto p = new perso;
            p->show();
            close();
        }
        if(vinto()){
            int p = 1000*colori*comb/(tent*riga_attiva);
            if(dup){
                p*2;
            }
            salva_punteggio();
            auto v = new class vinto;
            v->passa_punteggio(p);
            v->show();
            close();
        }

        riga_attiva += 1;
        attiva_riga(riga_attiva);
    }
}

void game::on_pushButton_clicked(){
    return; //non so come togliere
}


void game::on_conf_clicked()
{
    return;
}

