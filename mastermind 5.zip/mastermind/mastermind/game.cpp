#include "game.h"
#include "ui_game.h"
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string.h>
using namespace std;



game::game(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::game)
{


    ui->setupUi(this);
    ifstream fin("settings.txt");
    fin>> colori;
    fin>> comb;
    fin>> tent;
    fin>> dup;

    fin.close();

    setup();
}

game::~game()
{
    delete ui;
}



vector<string> game::genera_combinazione(){
    vector<string> ris;
    string col[colori];
    srand(time(NULL));
    for(int x = 0; x<colori; x++){
        col[x] = all_colori[x];
    }

    while (ris.size()<comb){
        int x = rand()%comb;
        if(col[x]!="x"){
            ris.push_back(col[x]);
            if(dup==false){
                col[x] = "x";
            }
        }
    }
    return ris;

}
// setup
void game::setup(){

    for(int x=colori;x<10;x++){
        if(all_colori[x]=="rosa"){ui->rosa->hide();}
        if(all_colori[x]=="viola"){ui->viola->hide();}
        if(all_colori[x]=="marrone"){ui->marrone->hide();}
        if(all_colori[x]=="azzurro"){ui->azzurro->hide();}
        if(all_colori[x]=="arancione"){ui->arancione->hide();}
        if(all_colori[x]=="grigio"){ui->grigio->hide();}
    }


    disattiva_colonna();


    ui->r2c1->hide();
    ui->r2c2->hide();
    ui->r2c3->hide();
    ui->r2c4->hide();
    ui->r2c5->hide();
    ui->r2c6->hide();
    ui->r2c7->hide();
    ui->r2c8->hide();
    ui->r2c9->hide();
    ui->r2c10->hide();

    ui->r3c1->hide();
    ui->r3c2->hide();
    ui->r3c3->hide();
    ui->r3c4->hide();
    ui->r3c5->hide();
    ui->r3c6->hide();
    ui->r3c7->hide();
    ui->r3c8->hide();
    ui->r3c9->hide();
    ui->r3c10->hide();

    ui->r4c1->hide();
    ui->r4c2->hide();
    ui->r4c3->hide();
    ui->r4c4->hide();
    ui->r4c5->hide();
    ui->r4c6->hide();
    ui->r4c7->hide();
    ui->r4c8->hide();
    ui->r4c9->hide();
    ui->r4c10->hide();

    ui->r5c1->hide();
    ui->r5c2->hide();
    ui->r5c3->hide();
    ui->r5c4->hide();
    ui->r5c5->hide();
    ui->r5c6->hide();
    ui->r5c7->hide();
    ui->r5c8->hide();
    ui->r5c9->hide();
    ui->r5c10->hide();

    ui->r6c1->hide();
    ui->r6c2->hide();
    ui->r6c3->hide();
    ui->r6c4->hide();
    ui->r6c5->hide();
    ui->r6c6->hide();
    ui->r6c7->hide();
    ui->r6c8->hide();
    ui->r6c9->hide();
    ui->r6c10->hide();

    ui->r7c1->hide();
    ui->r7c2->hide();
    ui->r7c3->hide();
    ui->r7c4->hide();
    ui->r7c5->hide();
    ui->r7c6->hide();
    ui->r7c7->hide();
    ui->r7c8->hide();
    ui->r7c9->hide();
    ui->r7c10->hide();

    ui->r8c1->hide();
    ui->r8c2->hide();
    ui->r8c3->hide();
    ui->r8c4->hide();
    ui->r8c5->hide();
    ui->r8c6->hide();
    ui->r8c7->hide();
    ui->r8c8->hide();
    ui->r8c9->hide();
    ui->r8c10->hide();

    ui->r9c1->hide();
    ui->r9c2->hide();
    ui->r9c3->hide();
    ui->r9c4->hide();
    ui->r9c5->hide();
    ui->r9c6->hide();
    ui->r9c7->hide();
    ui->r9c8->hide();
    ui->r9c9->hide();
    ui->r9c10->hide();

    ui->r10c1->hide();
    ui->r10c2->hide();
    ui->r10c3->hide();
    ui->r10c4->hide();
    ui->r10c5->hide();
    ui->r10c6->hide();
    ui->r10c7->hide();
    ui->r10c8->hide();
    ui->r10c9->hide();
    ui->r10c10->hide();

    combinazione = genera_combinazione();
    attiva_colonna(3);
}

void game::attiva_colonna(int num){
    if(num == 2){
        ui->r2c1->show();
        ui->r2c2->show();
        ui->r2c3->show();
        ui->r2c4->show();
        ui->r2c5->show();
        ui->r2c6->show();
        ui->r2c7->show();
        ui->r2c8->show();
        ui->r2c9->show();
        ui->r2c10->show();
    }
    if(num == 3){
        ui->r3c1->show();
        ui->r3c2->show();
        ui->r3c3->show();
        ui->r3c4->show();
        ui->r3c5->show();
        ui->r3c6->show();
        ui->r3c7->show();
        ui->r3c8->show();
        ui->r3c9->show();
        ui->r3c10->show();
    }
    if(num == 4){
        ui->r4c1->show();
        ui->r4c2->show();
        ui->r4c3->show();
        ui->r4c4->show();
        ui->r5c5->show();
        ui->r6c6->show();
        ui->r7c7->show();
        ui->r8c8->show();
        ui->r9c9->show();
        ui->r10c10->show();
    }
    if(num == 5){
        ui->r5c1->show();
        ui->r5c2->show();
        ui->r5c3->show();
        ui->r5c4->show();
        ui->r5c5->show();
        ui->r5c6->show();
        ui->r5c7->show();
        ui->r5c8->show();
        ui->r5c9->show();
        ui->r5c10->show();
    }
    if(num == 6){
        ui->r6c1->show();
        ui->r6c2->show();
        ui->r6c3->show();
        ui->r6c4->show();
        ui->r6c5->show();
        ui->r6c6->show();
        ui->r6c7->show();
        ui->r6c8->show();
        ui->r6c9->show();
        ui->r6c10->show();
    }
    if(num == 7){
        ui->r7c1->show();
        ui->r7c2->show();
        ui->r7c3->show();
        ui->r7c4->show();
        ui->r7c5->show();
        ui->r7c6->show();
        ui->r7c7->show();
        ui->r7c8->show();
        ui->r7c9->show();
        ui->r7c10->show();
    }
    if(num == 8){
        ui->r8c1->show();
        ui->r8c2->show();
        ui->r8c3->show();
        ui->r8c4->show();
        ui->r8c5->show();
        ui->r8c6->show();
        ui->r8c7->show();
        ui->r8c8->show();
        ui->r8c9->show();
        ui->r8c10->show();
    }
    if(num == 9){
        ui->r9c1->show();
        ui->r9c2->show();
        ui->r9c3->show();
        ui->r9c4->show();
        ui->r9c5->show();
        ui->r9c6->show();
        ui->r9c7->show();
        ui->r9c8->show();
        ui->r9c9->show();
        ui->r9c10->show();
    }
    if(num == 10){
        ui->r10c1->show();
        ui->r10c2->show();
        ui->r10c3->show();
        ui->r10c4->show();
        ui->r10c5->show();
        ui->r10c6->show();
        ui->r10c7->show();
        ui->r10c8->show();
        ui->r10c9->show();
        ui->r10c10->show();
    }
    disattiva_colonna();

}

void game::disattiva_colonna(){

    if(comb==4){
        ui->r1c1->close();
        ui->r2c1->close();
        ui->r3c1->close();
        ui->r4c1->close();
        ui->r5c1->close();
        ui->r6c1->close();
        ui->r7c1->close();
        ui->r8c1->close();
        ui->r9c1->close();
        ui->r10c1->close();

        ui->r1c2->close();
        ui->r2c2->close();
        ui->r3c2->close();
        ui->r4c2->close();
        ui->r5c2->close();
        ui->r6c2->close();
        ui->r7c2->close();
        ui->r8c2->close();
        ui->r9c2->close();
        ui->r10c2->close();

        ui->r1c3->close();
        ui->r2c3->close();
        ui->r3c3->close();
        ui->r4c3->close();
        ui->r5c3->close();
        ui->r6c3->close();
        ui->r7c3->close();
        ui->r8c3->close();
        ui->r9c3->close();
        ui->r10c3->close();

        ui->r1c8->close();
        ui->r2c8->close();
        ui->r3c8->close();
        ui->r4c8->close();
        ui->r5c8->close();
        ui->r6c8->close();
        ui->r7c8->close();
        ui->r8c8->close();
        ui->r9c8->close();
        ui->r10c8->close();

        ui->r1c9->close();
        ui->r2c9->close();
        ui->r3c9->close();
        ui->r4c9->close();
        ui->r5c9->close();
        ui->r6c9->close();
        ui->r7c9->close();
        ui->r8c9->close();
        ui->r9c9->close();
        ui->r10c9->close();

        ui->r1c10->close();
        ui->r2c10->close();
        ui->r3c10->close();
        ui->r4c10->close();
        ui->r5c10->close();
        ui->r6c10->close();
        ui->r7c10->close();
        ui->r8c10->close();
        ui->r9c10->close();
        ui->r10c10->close();
    }
    if(comb==5){
        ui->r1c1->close();
        ui->r2c1->close();
        ui->r3c1->close();
        ui->r4c1->close();
        ui->r5c1->close();
        ui->r6c1->close();
        ui->r7c1->close();
        ui->r8c1->close();
        ui->r9c1->close();
        ui->r10c1->close();

        ui->r1c2->close();
        ui->r2c2->close();
        ui->r3c2->close();
        ui->r4c2->close();
        ui->r5c2->close();
        ui->r6c2->close();
        ui->r7c2->close();
        ui->r8c2->close();
        ui->r9c2->close();
        ui->r10c2->close();

        ui->r1c8->close();
        ui->r2c8->close();
        ui->r3c8->close();
        ui->r4c8->close();
        ui->r5c8->close();
        ui->r6c8->close();
        ui->r7c8->close();
        ui->r8c8->close();
        ui->r9c8->close();
        ui->r10c8->close();

        ui->r1c9->close();
        ui->r2c9->close();
        ui->r3c9->close();
        ui->r4c9->close();
        ui->r5c9->close();
        ui->r6c9->close();
        ui->r7c9->close();
        ui->r8c9->close();
        ui->r9c9->close();
        ui->r10c9->close();

        ui->r1c10->close();
        ui->r2c10->close();
        ui->r3c10->close();
        ui->r4c10->close();
        ui->r5c10->close();
        ui->r6c10->close();
        ui->r7c10->close();
        ui->r8c10->close();
        ui->r9c10->close();
        ui->r10c10->close();
    }

    if(comb==6){
        ui->r1c1->close();
        ui->r2c1->close();
        ui->r3c1->close();
        ui->r4c1->close();
        ui->r5c1->close();
        ui->r6c1->close();
        ui->r7c1->close();
        ui->r8c1->close();
        ui->r9c1->close();
        ui->r10c1->close();

        ui->r1c2->close();
        ui->r2c2->close();
        ui->r3c2->close();
        ui->r4c2->close();
        ui->r5c2->close();
        ui->r6c2->close();
        ui->r7c2->close();
        ui->r8c2->close();
        ui->r9c2->close();
        ui->r10c2->close();

        ui->r1c9->close();
        ui->r2c9->close();
        ui->r3c9->close();
        ui->r4c9->close();
        ui->r5c9->close();
        ui->r6c9->close();
        ui->r7c9->close();
        ui->r8c9->close();
        ui->r9c9->close();
        ui->r10c9->close();

        ui->r1c10->close();
        ui->r2c10->close();
        ui->r3c10->close();
        ui->r4c10->close();
        ui->r5c10->close();
        ui->r6c10->close();
        ui->r7c10->close();
        ui->r8c10->close();
        ui->r9c10->close();
        ui->r10c10->close();
    }

    if(comb==7){
        ui->r1c1->close();
        ui->r2c1->close();
        ui->r3c1->close();
        ui->r4c1->close();
        ui->r5c1->close();
        ui->r6c1->close();
        ui->r7c1->close();
        ui->r8c1->close();
        ui->r9c1->close();
        ui->r10c1->close();

        ui->r1c9->close();
        ui->r2c9->close();
        ui->r3c9->close();
        ui->r4c9->close();
        ui->r5c9->close();
        ui->r6c9->close();
        ui->r7c9->close();
        ui->r8c9->close();
        ui->r9c9->close();
        ui->r10c9->close();

        ui->r1c10->close();
        ui->r2c10->close();
        ui->r3c10->close();
        ui->r4c10->close();
        ui->r5c10->close();
        ui->r6c10->close();
        ui->r7c10->close();
        ui->r8c10->close();
        ui->r9c10->close();
        ui->r10c10->close();
    }
    if(comb==8){
        ui->r1c1->close();
        ui->r2c1->close();
        ui->r3c1->close();
        ui->r4c1->close();
        ui->r5c1->close();
        ui->r6c1->close();
        ui->r7c1->close();
        ui->r8c1->close();
        ui->r9c1->close();
        ui->r10c1->close();

        ui->r1c10->close();
        ui->r2c10->close();
        ui->r3c10->close();
        ui->r4c10->close();
        ui->r5c10->close();
        ui->r6c10->close();
        ui->r7c10->close();
        ui->r8c10->close();
        ui->r9c10->close();
        ui->r10c10->close();
    }
    if(comb==9){
        ui->r1c10->close();
        ui->r2c10->close();
        ui->r3c10->close();
        ui->r4c10->close();
        ui->r5c10->close();
        ui->r6c10->close();
        ui->r7c10->close();
        ui->r8c10->close();
        ui->r9c10->close();
        ui->r10c10->close();
    }

}


//colori click
void game::on_rosso_clicked()
{
    colore = "rosso";
}
void game::on_blu_clicked()
{
    colore = "blu";
}
void game::on_verde_clicked()
{
    colore = "verde";
}
void game::on_giallo_clicked()
{
    colore = "giallo";
}
void game::on_rosa_clicked()
{
    colore = "rosa";
}
void game::on_viola_clicked()
{
    colore = "viola";
}
void game::on_marrone_clicked()
{
    colore = "marrone";
}
void game::on_azzurro_clicked()
{
    colore = "azzurro";
}
void game::on_arancione_clicked()
{
    colore = "arancione";
}
void game::on_grigio_clicked()
{
    colore = "grigio";
}

//spazio click
void game::on_r1c1_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r1c1->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r1c2_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r1c2->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r1c3_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r1c3->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r1c4_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r1c4->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r1c5_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r1c5->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r1c6_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r1c6->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r1c7_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r1c7->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r1c8_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r1c8->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r1c9_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r1c9->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r1c10_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r1c10->setStyleSheet(QString::fromStdString(new_style));
}

void game::on_r2c1_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r2c1->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r2c2_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r2c2->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r2c3_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r2c3->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r2c4_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r2c4->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r2c5_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r2c5->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r2c6_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r2c6->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r2c7_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r2c7->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r2c8_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r2c8->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r2c9_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r2c9->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r2c10_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r2c10->setStyleSheet(QString::fromStdString(new_style));
}

void game::on_r3c1_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r3c1->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r3c2_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r3c2->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r3c3_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r3c3->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r3c4_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r3c4->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r3c5_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r3c5->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r3c6_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r3c6->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r3c7_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r3c7->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r3c8_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r3c8->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r3c9_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r3c9->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r3c10_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r3c10->setStyleSheet(QString::fromStdString(new_style));
}

void game::on_r4c1_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r4c1->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r4c2_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r4c2->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r4c3_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r4c3->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r4c4_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r4c4->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r4c5_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r4c5->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r4c6_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r4c6->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r4c7_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r4c7->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r4c8_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r4c8->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r4c9_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r4c9->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r4c10_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r4c10->setStyleSheet(QString::fromStdString(new_style));
}

void game::on_r5c1_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r5c1->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r5c2_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r5c2->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r5c3_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r5c3->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r5c4_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r5c4->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r5c5_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r5c5->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r5c6_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r5c6->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r5c7_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r5c7->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r5c8_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r5c8->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r5c9_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r5c9->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r5c10_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r5c10->setStyleSheet(QString::fromStdString(new_style));
}


void game::on_r6c1_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r6c1->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r6c2_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r6c2->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r6c3_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r6c3->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r6c4_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r6c4->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r6c5_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r6c5->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r6c6_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r6c6->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r6c7_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r6c7->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r6c8_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r6c8->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r6c9_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r6c9->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r6c10_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r6c10->setStyleSheet(QString::fromStdString(new_style));
}

void game::on_r7c1_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r7c1->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r7c2_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r7c2->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r7c3_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r7c3->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r7c4_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r7c4->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r7c5_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r7c5->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r7c6_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r7c6->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r7c7_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r7c7->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r7c8_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r7c8->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r7c9_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r7c9->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r7c10_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r7c10->setStyleSheet(QString::fromStdString(new_style));
}

void game::on_r8c1_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r8c1->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r8c2_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r8c2->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r8c3_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r8c3->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r8c4_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r8c4->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r8c5_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r8c5->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r8c6_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r8c6->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r8c7_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r8c7->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r8c8_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r8c8->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r8c9_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r8c9->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r8c10_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r8c10->setStyleSheet(QString::fromStdString(new_style));
}

void game::on_r9c1_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r9c1->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r9c2_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r9c2->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r9c3_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r9c3->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r9c4_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r9c4->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r9c5_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r9c5->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r9c6_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r9c6->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r9c7_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r9c7->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r9c8_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r9c8->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r9c9_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r9c9->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r9c10_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r9c10->setStyleSheet(QString::fromStdString(new_style));
}


void game::on_r10c1_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r10c1->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r10c2_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r10c2->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r10c3_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r10c3->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r10c4_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r10c4->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r10c5_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r10c5->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r10c6_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r10c6->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r10c7_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r10c7->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r10c8_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r10c8->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r10c9_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r10c9->setStyleSheet(QString::fromStdString(new_style));
}
void game::on_r10c10_clicked()
{
    string new_style = "border-image: url(:/colori/colori/" + colore + "..png);";
    ui->r10c10->setStyleSheet(QString::fromStdString(new_style));
}

