/****************************************************************************
** Meta object code from reading C++ file 'game.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.12)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../mastermind/game.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'game.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.12. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_game_t {
    QByteArrayData data[112];
    char stringdata0[1803];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_game_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_game_t qt_meta_stringdata_game = {
    {
QT_MOC_LITERAL(0, 0, 4), // "game"
QT_MOC_LITERAL(1, 5, 16), // "on_rosso_clicked"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 14), // "on_blu_clicked"
QT_MOC_LITERAL(4, 38, 16), // "on_verde_clicked"
QT_MOC_LITERAL(5, 55, 17), // "on_giallo_clicked"
QT_MOC_LITERAL(6, 73, 15), // "on_rosa_clicked"
QT_MOC_LITERAL(7, 89, 16), // "on_viola_clicked"
QT_MOC_LITERAL(8, 106, 18), // "on_marrone_clicked"
QT_MOC_LITERAL(9, 125, 18), // "on_azzurro_clicked"
QT_MOC_LITERAL(10, 144, 20), // "on_arancione_clicked"
QT_MOC_LITERAL(11, 165, 17), // "on_grigio_clicked"
QT_MOC_LITERAL(12, 183, 15), // "on_r1c1_clicked"
QT_MOC_LITERAL(13, 199, 15), // "on_r1c2_clicked"
QT_MOC_LITERAL(14, 215, 15), // "on_r1c3_clicked"
QT_MOC_LITERAL(15, 231, 15), // "on_r1c4_clicked"
QT_MOC_LITERAL(16, 247, 15), // "on_r1c5_clicked"
QT_MOC_LITERAL(17, 263, 15), // "on_r1c6_clicked"
QT_MOC_LITERAL(18, 279, 15), // "on_r1c7_clicked"
QT_MOC_LITERAL(19, 295, 15), // "on_r1c8_clicked"
QT_MOC_LITERAL(20, 311, 15), // "on_r1c9_clicked"
QT_MOC_LITERAL(21, 327, 16), // "on_r1c10_clicked"
QT_MOC_LITERAL(22, 344, 15), // "on_r2c1_clicked"
QT_MOC_LITERAL(23, 360, 15), // "on_r2c2_clicked"
QT_MOC_LITERAL(24, 376, 15), // "on_r2c3_clicked"
QT_MOC_LITERAL(25, 392, 15), // "on_r2c4_clicked"
QT_MOC_LITERAL(26, 408, 15), // "on_r2c5_clicked"
QT_MOC_LITERAL(27, 424, 15), // "on_r2c6_clicked"
QT_MOC_LITERAL(28, 440, 15), // "on_r2c7_clicked"
QT_MOC_LITERAL(29, 456, 15), // "on_r2c8_clicked"
QT_MOC_LITERAL(30, 472, 15), // "on_r2c9_clicked"
QT_MOC_LITERAL(31, 488, 16), // "on_r2c10_clicked"
QT_MOC_LITERAL(32, 505, 15), // "on_r3c1_clicked"
QT_MOC_LITERAL(33, 521, 15), // "on_r3c2_clicked"
QT_MOC_LITERAL(34, 537, 15), // "on_r3c3_clicked"
QT_MOC_LITERAL(35, 553, 15), // "on_r3c4_clicked"
QT_MOC_LITERAL(36, 569, 15), // "on_r3c5_clicked"
QT_MOC_LITERAL(37, 585, 15), // "on_r3c6_clicked"
QT_MOC_LITERAL(38, 601, 15), // "on_r3c7_clicked"
QT_MOC_LITERAL(39, 617, 15), // "on_r3c8_clicked"
QT_MOC_LITERAL(40, 633, 15), // "on_r3c9_clicked"
QT_MOC_LITERAL(41, 649, 16), // "on_r3c10_clicked"
QT_MOC_LITERAL(42, 666, 15), // "on_r4c1_clicked"
QT_MOC_LITERAL(43, 682, 15), // "on_r4c2_clicked"
QT_MOC_LITERAL(44, 698, 15), // "on_r4c3_clicked"
QT_MOC_LITERAL(45, 714, 15), // "on_r4c4_clicked"
QT_MOC_LITERAL(46, 730, 15), // "on_r4c5_clicked"
QT_MOC_LITERAL(47, 746, 15), // "on_r4c6_clicked"
QT_MOC_LITERAL(48, 762, 15), // "on_r4c7_clicked"
QT_MOC_LITERAL(49, 778, 15), // "on_r4c8_clicked"
QT_MOC_LITERAL(50, 794, 15), // "on_r4c9_clicked"
QT_MOC_LITERAL(51, 810, 16), // "on_r4c10_clicked"
QT_MOC_LITERAL(52, 827, 15), // "on_r5c1_clicked"
QT_MOC_LITERAL(53, 843, 15), // "on_r5c2_clicked"
QT_MOC_LITERAL(54, 859, 15), // "on_r5c3_clicked"
QT_MOC_LITERAL(55, 875, 15), // "on_r5c4_clicked"
QT_MOC_LITERAL(56, 891, 15), // "on_r5c5_clicked"
QT_MOC_LITERAL(57, 907, 15), // "on_r5c6_clicked"
QT_MOC_LITERAL(58, 923, 15), // "on_r5c7_clicked"
QT_MOC_LITERAL(59, 939, 15), // "on_r5c8_clicked"
QT_MOC_LITERAL(60, 955, 15), // "on_r5c9_clicked"
QT_MOC_LITERAL(61, 971, 16), // "on_r5c10_clicked"
QT_MOC_LITERAL(62, 988, 15), // "on_r6c1_clicked"
QT_MOC_LITERAL(63, 1004, 15), // "on_r6c2_clicked"
QT_MOC_LITERAL(64, 1020, 15), // "on_r6c3_clicked"
QT_MOC_LITERAL(65, 1036, 15), // "on_r6c4_clicked"
QT_MOC_LITERAL(66, 1052, 15), // "on_r6c5_clicked"
QT_MOC_LITERAL(67, 1068, 15), // "on_r6c6_clicked"
QT_MOC_LITERAL(68, 1084, 15), // "on_r6c7_clicked"
QT_MOC_LITERAL(69, 1100, 15), // "on_r6c8_clicked"
QT_MOC_LITERAL(70, 1116, 15), // "on_r6c9_clicked"
QT_MOC_LITERAL(71, 1132, 16), // "on_r6c10_clicked"
QT_MOC_LITERAL(72, 1149, 15), // "on_r7c1_clicked"
QT_MOC_LITERAL(73, 1165, 15), // "on_r7c2_clicked"
QT_MOC_LITERAL(74, 1181, 15), // "on_r7c3_clicked"
QT_MOC_LITERAL(75, 1197, 15), // "on_r7c4_clicked"
QT_MOC_LITERAL(76, 1213, 15), // "on_r7c5_clicked"
QT_MOC_LITERAL(77, 1229, 15), // "on_r7c6_clicked"
QT_MOC_LITERAL(78, 1245, 15), // "on_r7c7_clicked"
QT_MOC_LITERAL(79, 1261, 15), // "on_r7c8_clicked"
QT_MOC_LITERAL(80, 1277, 15), // "on_r7c9_clicked"
QT_MOC_LITERAL(81, 1293, 16), // "on_r7c10_clicked"
QT_MOC_LITERAL(82, 1310, 15), // "on_r8c1_clicked"
QT_MOC_LITERAL(83, 1326, 15), // "on_r8c2_clicked"
QT_MOC_LITERAL(84, 1342, 15), // "on_r8c3_clicked"
QT_MOC_LITERAL(85, 1358, 15), // "on_r8c4_clicked"
QT_MOC_LITERAL(86, 1374, 15), // "on_r8c5_clicked"
QT_MOC_LITERAL(87, 1390, 15), // "on_r8c6_clicked"
QT_MOC_LITERAL(88, 1406, 15), // "on_r8c7_clicked"
QT_MOC_LITERAL(89, 1422, 15), // "on_r8c8_clicked"
QT_MOC_LITERAL(90, 1438, 15), // "on_r8c9_clicked"
QT_MOC_LITERAL(91, 1454, 16), // "on_r8c10_clicked"
QT_MOC_LITERAL(92, 1471, 15), // "on_r9c1_clicked"
QT_MOC_LITERAL(93, 1487, 15), // "on_r9c2_clicked"
QT_MOC_LITERAL(94, 1503, 15), // "on_r9c3_clicked"
QT_MOC_LITERAL(95, 1519, 15), // "on_r9c4_clicked"
QT_MOC_LITERAL(96, 1535, 15), // "on_r9c5_clicked"
QT_MOC_LITERAL(97, 1551, 15), // "on_r9c6_clicked"
QT_MOC_LITERAL(98, 1567, 15), // "on_r9c7_clicked"
QT_MOC_LITERAL(99, 1583, 15), // "on_r9c8_clicked"
QT_MOC_LITERAL(100, 1599, 15), // "on_r9c9_clicked"
QT_MOC_LITERAL(101, 1615, 16), // "on_r9c10_clicked"
QT_MOC_LITERAL(102, 1632, 16), // "on_r10c1_clicked"
QT_MOC_LITERAL(103, 1649, 16), // "on_r10c2_clicked"
QT_MOC_LITERAL(104, 1666, 16), // "on_r10c3_clicked"
QT_MOC_LITERAL(105, 1683, 16), // "on_r10c4_clicked"
QT_MOC_LITERAL(106, 1700, 16), // "on_r10c5_clicked"
QT_MOC_LITERAL(107, 1717, 16), // "on_r10c6_clicked"
QT_MOC_LITERAL(108, 1734, 16), // "on_r10c7_clicked"
QT_MOC_LITERAL(109, 1751, 16), // "on_r10c8_clicked"
QT_MOC_LITERAL(110, 1768, 16), // "on_r10c9_clicked"
QT_MOC_LITERAL(111, 1785, 17) // "on_r10c10_clicked"

    },
    "game\0on_rosso_clicked\0\0on_blu_clicked\0"
    "on_verde_clicked\0on_giallo_clicked\0"
    "on_rosa_clicked\0on_viola_clicked\0"
    "on_marrone_clicked\0on_azzurro_clicked\0"
    "on_arancione_clicked\0on_grigio_clicked\0"
    "on_r1c1_clicked\0on_r1c2_clicked\0"
    "on_r1c3_clicked\0on_r1c4_clicked\0"
    "on_r1c5_clicked\0on_r1c6_clicked\0"
    "on_r1c7_clicked\0on_r1c8_clicked\0"
    "on_r1c9_clicked\0on_r1c10_clicked\0"
    "on_r2c1_clicked\0on_r2c2_clicked\0"
    "on_r2c3_clicked\0on_r2c4_clicked\0"
    "on_r2c5_clicked\0on_r2c6_clicked\0"
    "on_r2c7_clicked\0on_r2c8_clicked\0"
    "on_r2c9_clicked\0on_r2c10_clicked\0"
    "on_r3c1_clicked\0on_r3c2_clicked\0"
    "on_r3c3_clicked\0on_r3c4_clicked\0"
    "on_r3c5_clicked\0on_r3c6_clicked\0"
    "on_r3c7_clicked\0on_r3c8_clicked\0"
    "on_r3c9_clicked\0on_r3c10_clicked\0"
    "on_r4c1_clicked\0on_r4c2_clicked\0"
    "on_r4c3_clicked\0on_r4c4_clicked\0"
    "on_r4c5_clicked\0on_r4c6_clicked\0"
    "on_r4c7_clicked\0on_r4c8_clicked\0"
    "on_r4c9_clicked\0on_r4c10_clicked\0"
    "on_r5c1_clicked\0on_r5c2_clicked\0"
    "on_r5c3_clicked\0on_r5c4_clicked\0"
    "on_r5c5_clicked\0on_r5c6_clicked\0"
    "on_r5c7_clicked\0on_r5c8_clicked\0"
    "on_r5c9_clicked\0on_r5c10_clicked\0"
    "on_r6c1_clicked\0on_r6c2_clicked\0"
    "on_r6c3_clicked\0on_r6c4_clicked\0"
    "on_r6c5_clicked\0on_r6c6_clicked\0"
    "on_r6c7_clicked\0on_r6c8_clicked\0"
    "on_r6c9_clicked\0on_r6c10_clicked\0"
    "on_r7c1_clicked\0on_r7c2_clicked\0"
    "on_r7c3_clicked\0on_r7c4_clicked\0"
    "on_r7c5_clicked\0on_r7c6_clicked\0"
    "on_r7c7_clicked\0on_r7c8_clicked\0"
    "on_r7c9_clicked\0on_r7c10_clicked\0"
    "on_r8c1_clicked\0on_r8c2_clicked\0"
    "on_r8c3_clicked\0on_r8c4_clicked\0"
    "on_r8c5_clicked\0on_r8c6_clicked\0"
    "on_r8c7_clicked\0on_r8c8_clicked\0"
    "on_r8c9_clicked\0on_r8c10_clicked\0"
    "on_r9c1_clicked\0on_r9c2_clicked\0"
    "on_r9c3_clicked\0on_r9c4_clicked\0"
    "on_r9c5_clicked\0on_r9c6_clicked\0"
    "on_r9c7_clicked\0on_r9c8_clicked\0"
    "on_r9c9_clicked\0on_r9c10_clicked\0"
    "on_r10c1_clicked\0on_r10c2_clicked\0"
    "on_r10c3_clicked\0on_r10c4_clicked\0"
    "on_r10c5_clicked\0on_r10c6_clicked\0"
    "on_r10c7_clicked\0on_r10c8_clicked\0"
    "on_r10c9_clicked\0on_r10c10_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_game[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
     110,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  564,    2, 0x08 /* Private */,
       3,    0,  565,    2, 0x08 /* Private */,
       4,    0,  566,    2, 0x08 /* Private */,
       5,    0,  567,    2, 0x08 /* Private */,
       6,    0,  568,    2, 0x08 /* Private */,
       7,    0,  569,    2, 0x08 /* Private */,
       8,    0,  570,    2, 0x08 /* Private */,
       9,    0,  571,    2, 0x08 /* Private */,
      10,    0,  572,    2, 0x08 /* Private */,
      11,    0,  573,    2, 0x08 /* Private */,
      12,    0,  574,    2, 0x08 /* Private */,
      13,    0,  575,    2, 0x08 /* Private */,
      14,    0,  576,    2, 0x08 /* Private */,
      15,    0,  577,    2, 0x08 /* Private */,
      16,    0,  578,    2, 0x08 /* Private */,
      17,    0,  579,    2, 0x08 /* Private */,
      18,    0,  580,    2, 0x08 /* Private */,
      19,    0,  581,    2, 0x08 /* Private */,
      20,    0,  582,    2, 0x08 /* Private */,
      21,    0,  583,    2, 0x08 /* Private */,
      22,    0,  584,    2, 0x08 /* Private */,
      23,    0,  585,    2, 0x08 /* Private */,
      24,    0,  586,    2, 0x08 /* Private */,
      25,    0,  587,    2, 0x08 /* Private */,
      26,    0,  588,    2, 0x08 /* Private */,
      27,    0,  589,    2, 0x08 /* Private */,
      28,    0,  590,    2, 0x08 /* Private */,
      29,    0,  591,    2, 0x08 /* Private */,
      30,    0,  592,    2, 0x08 /* Private */,
      31,    0,  593,    2, 0x08 /* Private */,
      32,    0,  594,    2, 0x08 /* Private */,
      33,    0,  595,    2, 0x08 /* Private */,
      34,    0,  596,    2, 0x08 /* Private */,
      35,    0,  597,    2, 0x08 /* Private */,
      36,    0,  598,    2, 0x08 /* Private */,
      37,    0,  599,    2, 0x08 /* Private */,
      38,    0,  600,    2, 0x08 /* Private */,
      39,    0,  601,    2, 0x08 /* Private */,
      40,    0,  602,    2, 0x08 /* Private */,
      41,    0,  603,    2, 0x08 /* Private */,
      42,    0,  604,    2, 0x08 /* Private */,
      43,    0,  605,    2, 0x08 /* Private */,
      44,    0,  606,    2, 0x08 /* Private */,
      45,    0,  607,    2, 0x08 /* Private */,
      46,    0,  608,    2, 0x08 /* Private */,
      47,    0,  609,    2, 0x08 /* Private */,
      48,    0,  610,    2, 0x08 /* Private */,
      49,    0,  611,    2, 0x08 /* Private */,
      50,    0,  612,    2, 0x08 /* Private */,
      51,    0,  613,    2, 0x08 /* Private */,
      52,    0,  614,    2, 0x08 /* Private */,
      53,    0,  615,    2, 0x08 /* Private */,
      54,    0,  616,    2, 0x08 /* Private */,
      55,    0,  617,    2, 0x08 /* Private */,
      56,    0,  618,    2, 0x08 /* Private */,
      57,    0,  619,    2, 0x08 /* Private */,
      58,    0,  620,    2, 0x08 /* Private */,
      59,    0,  621,    2, 0x08 /* Private */,
      60,    0,  622,    2, 0x08 /* Private */,
      61,    0,  623,    2, 0x08 /* Private */,
      62,    0,  624,    2, 0x08 /* Private */,
      63,    0,  625,    2, 0x08 /* Private */,
      64,    0,  626,    2, 0x08 /* Private */,
      65,    0,  627,    2, 0x08 /* Private */,
      66,    0,  628,    2, 0x08 /* Private */,
      67,    0,  629,    2, 0x08 /* Private */,
      68,    0,  630,    2, 0x08 /* Private */,
      69,    0,  631,    2, 0x08 /* Private */,
      70,    0,  632,    2, 0x08 /* Private */,
      71,    0,  633,    2, 0x08 /* Private */,
      72,    0,  634,    2, 0x08 /* Private */,
      73,    0,  635,    2, 0x08 /* Private */,
      74,    0,  636,    2, 0x08 /* Private */,
      75,    0,  637,    2, 0x08 /* Private */,
      76,    0,  638,    2, 0x08 /* Private */,
      77,    0,  639,    2, 0x08 /* Private */,
      78,    0,  640,    2, 0x08 /* Private */,
      79,    0,  641,    2, 0x08 /* Private */,
      80,    0,  642,    2, 0x08 /* Private */,
      81,    0,  643,    2, 0x08 /* Private */,
      82,    0,  644,    2, 0x08 /* Private */,
      83,    0,  645,    2, 0x08 /* Private */,
      84,    0,  646,    2, 0x08 /* Private */,
      85,    0,  647,    2, 0x08 /* Private */,
      86,    0,  648,    2, 0x08 /* Private */,
      87,    0,  649,    2, 0x08 /* Private */,
      88,    0,  650,    2, 0x08 /* Private */,
      89,    0,  651,    2, 0x08 /* Private */,
      90,    0,  652,    2, 0x08 /* Private */,
      91,    0,  653,    2, 0x08 /* Private */,
      92,    0,  654,    2, 0x08 /* Private */,
      93,    0,  655,    2, 0x08 /* Private */,
      94,    0,  656,    2, 0x08 /* Private */,
      95,    0,  657,    2, 0x08 /* Private */,
      96,    0,  658,    2, 0x08 /* Private */,
      97,    0,  659,    2, 0x08 /* Private */,
      98,    0,  660,    2, 0x08 /* Private */,
      99,    0,  661,    2, 0x08 /* Private */,
     100,    0,  662,    2, 0x08 /* Private */,
     101,    0,  663,    2, 0x08 /* Private */,
     102,    0,  664,    2, 0x08 /* Private */,
     103,    0,  665,    2, 0x08 /* Private */,
     104,    0,  666,    2, 0x08 /* Private */,
     105,    0,  667,    2, 0x08 /* Private */,
     106,    0,  668,    2, 0x08 /* Private */,
     107,    0,  669,    2, 0x08 /* Private */,
     108,    0,  670,    2, 0x08 /* Private */,
     109,    0,  671,    2, 0x08 /* Private */,
     110,    0,  672,    2, 0x08 /* Private */,
     111,    0,  673,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void game::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<game *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_rosso_clicked(); break;
        case 1: _t->on_blu_clicked(); break;
        case 2: _t->on_verde_clicked(); break;
        case 3: _t->on_giallo_clicked(); break;
        case 4: _t->on_rosa_clicked(); break;
        case 5: _t->on_viola_clicked(); break;
        case 6: _t->on_marrone_clicked(); break;
        case 7: _t->on_azzurro_clicked(); break;
        case 8: _t->on_arancione_clicked(); break;
        case 9: _t->on_grigio_clicked(); break;
        case 10: _t->on_r1c1_clicked(); break;
        case 11: _t->on_r1c2_clicked(); break;
        case 12: _t->on_r1c3_clicked(); break;
        case 13: _t->on_r1c4_clicked(); break;
        case 14: _t->on_r1c5_clicked(); break;
        case 15: _t->on_r1c6_clicked(); break;
        case 16: _t->on_r1c7_clicked(); break;
        case 17: _t->on_r1c8_clicked(); break;
        case 18: _t->on_r1c9_clicked(); break;
        case 19: _t->on_r1c10_clicked(); break;
        case 20: _t->on_r2c1_clicked(); break;
        case 21: _t->on_r2c2_clicked(); break;
        case 22: _t->on_r2c3_clicked(); break;
        case 23: _t->on_r2c4_clicked(); break;
        case 24: _t->on_r2c5_clicked(); break;
        case 25: _t->on_r2c6_clicked(); break;
        case 26: _t->on_r2c7_clicked(); break;
        case 27: _t->on_r2c8_clicked(); break;
        case 28: _t->on_r2c9_clicked(); break;
        case 29: _t->on_r2c10_clicked(); break;
        case 30: _t->on_r3c1_clicked(); break;
        case 31: _t->on_r3c2_clicked(); break;
        case 32: _t->on_r3c3_clicked(); break;
        case 33: _t->on_r3c4_clicked(); break;
        case 34: _t->on_r3c5_clicked(); break;
        case 35: _t->on_r3c6_clicked(); break;
        case 36: _t->on_r3c7_clicked(); break;
        case 37: _t->on_r3c8_clicked(); break;
        case 38: _t->on_r3c9_clicked(); break;
        case 39: _t->on_r3c10_clicked(); break;
        case 40: _t->on_r4c1_clicked(); break;
        case 41: _t->on_r4c2_clicked(); break;
        case 42: _t->on_r4c3_clicked(); break;
        case 43: _t->on_r4c4_clicked(); break;
        case 44: _t->on_r4c5_clicked(); break;
        case 45: _t->on_r4c6_clicked(); break;
        case 46: _t->on_r4c7_clicked(); break;
        case 47: _t->on_r4c8_clicked(); break;
        case 48: _t->on_r4c9_clicked(); break;
        case 49: _t->on_r4c10_clicked(); break;
        case 50: _t->on_r5c1_clicked(); break;
        case 51: _t->on_r5c2_clicked(); break;
        case 52: _t->on_r5c3_clicked(); break;
        case 53: _t->on_r5c4_clicked(); break;
        case 54: _t->on_r5c5_clicked(); break;
        case 55: _t->on_r5c6_clicked(); break;
        case 56: _t->on_r5c7_clicked(); break;
        case 57: _t->on_r5c8_clicked(); break;
        case 58: _t->on_r5c9_clicked(); break;
        case 59: _t->on_r5c10_clicked(); break;
        case 60: _t->on_r6c1_clicked(); break;
        case 61: _t->on_r6c2_clicked(); break;
        case 62: _t->on_r6c3_clicked(); break;
        case 63: _t->on_r6c4_clicked(); break;
        case 64: _t->on_r6c5_clicked(); break;
        case 65: _t->on_r6c6_clicked(); break;
        case 66: _t->on_r6c7_clicked(); break;
        case 67: _t->on_r6c8_clicked(); break;
        case 68: _t->on_r6c9_clicked(); break;
        case 69: _t->on_r6c10_clicked(); break;
        case 70: _t->on_r7c1_clicked(); break;
        case 71: _t->on_r7c2_clicked(); break;
        case 72: _t->on_r7c3_clicked(); break;
        case 73: _t->on_r7c4_clicked(); break;
        case 74: _t->on_r7c5_clicked(); break;
        case 75: _t->on_r7c6_clicked(); break;
        case 76: _t->on_r7c7_clicked(); break;
        case 77: _t->on_r7c8_clicked(); break;
        case 78: _t->on_r7c9_clicked(); break;
        case 79: _t->on_r7c10_clicked(); break;
        case 80: _t->on_r8c1_clicked(); break;
        case 81: _t->on_r8c2_clicked(); break;
        case 82: _t->on_r8c3_clicked(); break;
        case 83: _t->on_r8c4_clicked(); break;
        case 84: _t->on_r8c5_clicked(); break;
        case 85: _t->on_r8c6_clicked(); break;
        case 86: _t->on_r8c7_clicked(); break;
        case 87: _t->on_r8c8_clicked(); break;
        case 88: _t->on_r8c9_clicked(); break;
        case 89: _t->on_r8c10_clicked(); break;
        case 90: _t->on_r9c1_clicked(); break;
        case 91: _t->on_r9c2_clicked(); break;
        case 92: _t->on_r9c3_clicked(); break;
        case 93: _t->on_r9c4_clicked(); break;
        case 94: _t->on_r9c5_clicked(); break;
        case 95: _t->on_r9c6_clicked(); break;
        case 96: _t->on_r9c7_clicked(); break;
        case 97: _t->on_r9c8_clicked(); break;
        case 98: _t->on_r9c9_clicked(); break;
        case 99: _t->on_r9c10_clicked(); break;
        case 100: _t->on_r10c1_clicked(); break;
        case 101: _t->on_r10c2_clicked(); break;
        case 102: _t->on_r10c3_clicked(); break;
        case 103: _t->on_r10c4_clicked(); break;
        case 104: _t->on_r10c5_clicked(); break;
        case 105: _t->on_r10c6_clicked(); break;
        case 106: _t->on_r10c7_clicked(); break;
        case 107: _t->on_r10c8_clicked(); break;
        case 108: _t->on_r10c9_clicked(); break;
        case 109: _t->on_r10c10_clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject game::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_game.data,
    qt_meta_data_game,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *game::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *game::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_game.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int game::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 110)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 110;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 110)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 110;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
