/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionfinalmente;
    QWidget *centralwidget;
    QTextBrowser *textBrowser;
    QTextEdit *titolo;
    QPushButton *play;
    QPushButton *settings;
    QPushButton *exit;
    QMenuBar *menubar;
    QMenu *menuclick_me;
    QMenu *menueh_eh;
    QMenu *menuancora_uno;
    QMenu *menuno_dai_ancora_una;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1313, 710);
        actionfinalmente = new QAction(MainWindow);
        actionfinalmente->setObjectName(QString::fromUtf8("actionfinalmente"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        textBrowser = new QTextBrowser(centralwidget);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(260, 110, 851, 141));
        QFont font;
        font.setFamily(QString::fromUtf8("Courier New"));
        font.setPointSize(72);
        textBrowser->setFont(font);
        textBrowser->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        titolo = new QTextEdit(centralwidget);
        titolo->setObjectName(QString::fromUtf8("titolo"));
        titolo->setGeometry(QRect(-30, -10, 1341, 711));
        titolo->setStyleSheet(QString::fromUtf8("background-color: rgb(47, 47, 47);"));
        play = new QPushButton(centralwidget);
        play->setObjectName(QString::fromUtf8("play"));
        play->setGeometry(QRect(550, 320, 311, 61));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Courier New"));
        font1.setPointSize(36);
        play->setFont(font1);
        play->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        settings = new QPushButton(centralwidget);
        settings->setObjectName(QString::fromUtf8("settings"));
        settings->setGeometry(QRect(550, 420, 311, 61));
        settings->setFont(font1);
        settings->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        exit = new QPushButton(centralwidget);
        exit->setObjectName(QString::fromUtf8("exit"));
        exit->setGeometry(QRect(550, 520, 311, 61));
        exit->setFont(font1);
        exit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        MainWindow->setCentralWidget(centralwidget);
        titolo->raise();
        textBrowser->raise();
        play->raise();
        settings->raise();
        exit->raise();
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1313, 26));
        menuclick_me = new QMenu(menubar);
        menuclick_me->setObjectName(QString::fromUtf8("menuclick_me"));
        menueh_eh = new QMenu(menuclick_me);
        menueh_eh->setObjectName(QString::fromUtf8("menueh_eh"));
        menuancora_uno = new QMenu(menueh_eh);
        menuancora_uno->setObjectName(QString::fromUtf8("menuancora_uno"));
        menuno_dai_ancora_una = new QMenu(menuancora_uno);
        menuno_dai_ancora_una->setObjectName(QString::fromUtf8("menuno_dai_ancora_una"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menuclick_me->menuAction());
        menuclick_me->addAction(menueh_eh->menuAction());
        menueh_eh->addAction(menuancora_uno->menuAction());
        menuancora_uno->addAction(menuno_dai_ancora_una->menuAction());
        menuno_dai_ancora_una->addAction(actionfinalmente);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        actionfinalmente->setText(QApplication::translate("MainWindow", "finalmente!", nullptr));
        textBrowser->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Courier New'; font-size:72pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">MASTERMIND</p></body></html>", nullptr));
        play->setText(QApplication::translate("MainWindow", "PLAY", nullptr));
        settings->setText(QApplication::translate("MainWindow", "SETTINGS", nullptr));
        exit->setText(QApplication::translate("MainWindow", "EXIT", nullptr));
        menuclick_me->setTitle(QApplication::translate("MainWindow", "click me :)", nullptr));
        menueh_eh->setTitle(QApplication::translate("MainWindow", "eh eh", nullptr));
        menuancora_uno->setTitle(QApplication::translate("MainWindow", "ancora uno", nullptr));
        menuno_dai_ancora_una->setTitle(QApplication::translate("MainWindow", "no dai ancora una", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
