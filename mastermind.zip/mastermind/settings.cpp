#include "settings.h"
#include "ui_settings.h"
#include "mainwindow.h"
settings::settings(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::settings)
{
    ui->setupUi(this);
}

settings::~settings()
{
    delete ui;
}

void settings::on_play_2_clicked()
{
    auto sett = new MainWindow;
    sett->show();
    close();
}

