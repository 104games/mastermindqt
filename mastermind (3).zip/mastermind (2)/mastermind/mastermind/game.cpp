#include "game.h"
#include "ui_game.h"
#include <fstream>
#include <iostream>
using namespace std;
game::game(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::game)
{
    cout << "ciao";

    ui->setupUi(this);
    ifstream fin("settings.txt");
    fin>> colori;
    fin>> comb;
    fin>> tent;
    fin>> dup;
    cout<< colori;
}

game::~game()
{
    delete ui;
}
