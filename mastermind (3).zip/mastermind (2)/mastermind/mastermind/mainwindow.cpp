#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "settings.h"
#include "game.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_settings_clicked()
{
    auto sett = new settings;
    sett->show();
    close();
}


void MainWindow::on_play_clicked()
{
    auto sett = new game;
    sett->show();
    close();
}


void MainWindow::on_exit_clicked()
{
    close();
}

