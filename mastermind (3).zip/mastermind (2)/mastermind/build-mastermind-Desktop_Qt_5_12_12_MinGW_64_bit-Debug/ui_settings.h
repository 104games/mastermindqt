/********************************************************************************
** Form generated from reading UI file 'settings.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGS_H
#define UI_SETTINGS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_settings
{
public:
    QTextEdit *titolo_2;
    QTextBrowser *test;
    QTextBrowser *textBrowser_2;
    QTextBrowser *textBrowser_3;
    QSpinBox *colori;
    QSpinBox *comb;
    QSpinBox *tent;
    QPushButton *play;
    QPushButton *play_2;
    QCheckBox *duplicati;

    void setupUi(QWidget *settings)
    {
        if (settings->objectName().isEmpty())
            settings->setObjectName(QString::fromUtf8("settings"));
        settings->resize(1312, 711);
        titolo_2 = new QTextEdit(settings);
        titolo_2->setObjectName(QString::fromUtf8("titolo_2"));
        titolo_2->setGeometry(QRect(10, -20, 1381, 741));
        titolo_2->setStyleSheet(QString::fromUtf8("background-color: rgb(47, 47, 47);"));
        test = new QTextBrowser(settings);
        test->setObjectName(QString::fromUtf8("test"));
        test->setGeometry(QRect(30, 30, 811, 121));
        QFont font;
        font.setFamily(QString::fromUtf8("Courier New"));
        font.setPointSize(72);
        test->setFont(font);
        test->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        textBrowser_2 = new QTextBrowser(settings);
        textBrowser_2->setObjectName(QString::fromUtf8("textBrowser_2"));
        textBrowser_2->setGeometry(QRect(60, 220, 731, 121));
        textBrowser_2->setFont(font);
        textBrowser_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        textBrowser_3 = new QTextBrowser(settings);
        textBrowser_3->setObjectName(QString::fromUtf8("textBrowser_3"));
        textBrowser_3->setGeometry(QRect(150, 380, 541, 121));
        textBrowser_3->setFont(font);
        textBrowser_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        colori = new QSpinBox(settings);
        colori->setObjectName(QString::fromUtf8("colori"));
        colori->setGeometry(QRect(950, 80, 171, 91));
        QFont font1;
        font1.setPointSize(32);
        colori->setFont(font1);
        colori->setMinimum(4);
        colori->setMaximum(10);
        comb = new QSpinBox(settings);
        comb->setObjectName(QString::fromUtf8("comb"));
        comb->setGeometry(QRect(950, 230, 171, 91));
        comb->setFont(font1);
        comb->setMinimum(4);
        comb->setMaximum(10);
        tent = new QSpinBox(settings);
        tent->setObjectName(QString::fromUtf8("tent"));
        tent->setGeometry(QRect(950, 400, 171, 91));
        tent->setFont(font1);
        tent->setMinimum(1);
        tent->setMaximum(10);
        play = new QPushButton(settings);
        play->setObjectName(QString::fromUtf8("play"));
        play->setGeometry(QRect(560, 550, 241, 61));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Courier New"));
        font2.setPointSize(36);
        play->setFont(font2);
        play->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        play_2 = new QPushButton(settings);
        play_2->setObjectName(QString::fromUtf8("play_2"));
        play_2->setGeometry(QRect(560, 630, 241, 61));
        play_2->setFont(font2);
        play_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        duplicati = new QCheckBox(settings);
        duplicati->setObjectName(QString::fromUtf8("duplicati"));
        duplicati->setGeometry(QRect(140, 590, 371, 91));
        duplicati->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        retranslateUi(settings);

        QMetaObject::connectSlotsByName(settings);
    } // setupUi

    void retranslateUi(QWidget *settings)
    {
        settings->setWindowTitle(QApplication::translate("settings", "Form", nullptr));
        test->setHtml(QApplication::translate("settings", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Courier New'; font-size:72pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">colori</p></body></html>", nullptr));
        textBrowser_2->setHtml(QApplication::translate("settings", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Courier New'; font-size:72pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">combinazione</p></body></html>", nullptr));
        textBrowser_3->setHtml(QApplication::translate("settings", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Courier New'; font-size:72pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">tentativi</p></body></html>", nullptr));
        play->setText(QApplication::translate("settings", "save", nullptr));
        play_2->setText(QApplication::translate("settings", "back", nullptr));
        duplicati->setText(QApplication::translate("settings", "duplicati", nullptr));
    } // retranslateUi

};

namespace Ui {
    class settings: public Ui_settings {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGS_H
